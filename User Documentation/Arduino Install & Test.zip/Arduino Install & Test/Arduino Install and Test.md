## Guitar Effects Processor Arduino Install

#### Install the pre-configured Arduino application and compile first sketch.

This assumes the USB stick (or thumb drive or whatever you want to call it) is inserted in the Macbook. The exact name and location may not match since I didn't make a copy and I'm not sure of the directory structure.

Locate these folders on the USB stick before starting:
```
    Arduino_1810
    Arduino_15
    libraries
    Teensy_GEP_170
```

#### Notes:
Your home directory is your user folder thats opens when you log in, which is located at /Users/your-user-name. From here on, it is assumed to be 'dsmith'. The terms folder and directory are used interchangeably.


1) Locate the Arduino application folder on the USB stick (could be named 'Arduino_1810' since 1.8.10 is the version). Copy the folder to your Applications folder.

2) Copy the folder labeled 'Arduino15' to your Library folder in your home folder (/Users/dsmith/Library).
Note: if the Library folder is not visible in your home folder, select any folder in your home directory and click View -> Show View Options in the menu. Near the bottom of the view options select "Show Library Folder"

3) Launch the Arduino application in the Applications folder. You may opt to keep it in the dock by left-clicking the Arduino dock icon and selecting -> Options -> Keep in Dock

4) The Arduino app should open and display a new sketch folder. 

5) Copy & paste the following code in the new sketch folder. It simply prints 'Test' to the screen once a second.

    ```
    void setup()
    {
        Serial.begin(57600);
    }


    void loop()
    {
        Serial.println("Test");
        delay(1000);
    }
    ```
    
    ![image](tools.png)

6) Under the Tools menu, select the following:
    ```
    Board -> Teensy 3.6
    USB Type -> Serial
    CPU Speed -> 180 MHz
    Optimize -> Faster
    Keyboard Layout -> US English
    ```
    
Port - You won't be able to select a port until you plug in the GEP later.
    
This selects a Teensy version 3.6 at 180 MHz (full speed). Code optimization can be fast, faster, or fastest. Port is the serial/USB port used to program the teensy later.

    ![image](icons.png)

7) At the upper left in the Arduino title bar is 5 round buttons. The first is a Check Mark which verifies & compiles the code but doesn't load it into the target device (Teensy). Go ahead and click it. If all goes well, once your code finishes compiling a new window will pop up titled Teensy. This is the Teensy Loader program and is what transfers the code you just compiled to the Teensy, which we'll do it a second.

8) Go find a USB cable that will connect the laptop to the Teensy GEP connector on the top (a 'type A' to 'type B'). Connect the GEP to your laptop. The GEP should power up.

Note: Its generally not a good idea to have the GEP powered by both the power adapter and USB simultaneously. The Mac USB port can handle it if the power adapter is outputting no more than about 5.2V. But if something went wrong....

    ![image](port.png)

9) Once the GEP boots up, go to the Tools menu and select Port. Click on the serial port for the Teensy labeled something like '/dev/cu.usbmodemxxxxxx'. Its probably the only choice other than bluetooth.

10) Press the 'Upload' button next to the verify button. You may be asked to save the file, pick a name and click save. You code will compile and the Teensy Loader program will copy it to the Teensy. Status messages are displayed at the bottom of the window.

    ![image](terminal.png)

11) Once you see 'upload complete', click on the magnifying glass icon in the Arduino title bar. This will bring up a serial terminal and show you the output from the Teensy.
You should see something like this...

    ![image](output.png)

12) Ta-da! You just wrote, compiled, and uploaded your first Arduino sketch (or maybe not). But in the process, you overwrote the code in GEP. That's next.

13) Quit Arduino.

14) Copy the Teensy_GEP_170 sketch folder on the USB Stick to the Arduino folder now located in your home folder (Arduino created this as your default sketch folder). 

15) Copy the contents of the folder titled 'libraries' to the folder named 'libraries' in the new Arduino folder on your computer. Libraries are shared code and device drivers for various sensors, displays, algorithms, and more. There's a Library Manager under Sketch -> Include Library -> Manage Libraries where you can add more, plus there's scads of libraries on the internet. One of the nice things about Sparkfun and Adafruit (where I buy most my stuff) is they include libraries for almost everything they sell.

15) Re-launch the Arduino app.

16) In Arduino, select File -> Sketchbook -> Teensy_GEP_170. This will open the GEP sketch which has about a dozen tabs. FYI: The main tab is always the name of the Sketch and is always located in a folder with the same name. So sketch Test.ino must be in a folder name Test.

17) Click the Upload button, wait about 2 minutes, and the you should see the Teensy loader program transfer the compiled code to Teensy. Teensy should reboot, and now run the GEP program.

18) Your done. I can now send you updates, test effect sketches, and other fun stuff. Feel free to play around with the GEP code.

19) The [Arduino website](https://arduino.cc) website has lots of tutorials, example code, and a language reference. There's also a language reference located in the Arduino app under Help -> Reference. There's is also lots of examples located in Arduino in the File -> Examples menu.


    

    