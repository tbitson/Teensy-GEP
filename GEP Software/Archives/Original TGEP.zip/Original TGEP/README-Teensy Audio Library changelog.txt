Change log for Teensy Audio library by BM
NOTE: I changed these in both the documents/arduino... audio folder, as well as
program files(x86) arduino ... hardware .... teensy... audio folder
BECAUSE UPDATES to TD are made in the latter folder

1) as posted to forum:  (also added an issue on pauls github site Nov 9,2016 )
Teensyduino vers: 1.29

 The SGTL5000 AutoVolumeControl function does not work as described.
 There are 3 incorrect lines in the code which result in the
 Threshold (16-bit), Attack(12-bit) and Decay(12-bit) registers
 of the SCTL5000 being loaded incorrectly.

 In the file "control_sgtl5000.cpp" the following 3 lines

 Line#
 844 uint8_t thresh = (pow(10, threshold / 20)*0.636)*pow(2, 15); 
 845 uint8_t att=(1-pow(10,-(attack/(20*44100))))*pow(2,19); 
 846 uint8_t dec=(1-pow(10,-(decay/(20*44100))))*pow(2,23); 

 should be replaced with
 uint16_t thresh = (pow(10, threshold / 20)*0.636)*pow(2, 15); 
 uint16_t att=(1-pow(10,-(attack/(20*44100))))*pow(2,19); 
 uint16_t dec=(1-pow(10,-(decay/(20*44100))))*pow(2,23); 

 This loads the registers with the proper 16, 12-bit values,
 and when I tested it out on the Audioshield, the AVC now works properly. ) 

2) in Control_SGTL5000.h
moved the functions read, write and modify from private to public, so I could 
access the registers directly from main program.

3)in effect_flange.cpp
Sent to forum-
I am using Version Teensy 1.29

In my tests (using audio shield and a guitar signal) , the flange effect does 
not produce the correct "sweeping comb-filter" effect that it should. I have 
traced the problem to the following lines in effect_flange.cpp
in AudioEffectFlange.begin routine:

line 80 delay_rate_incr = delay_rate / (2147483648.0 * AUDIO_SAMPLE_RATE_EXACT)

and similarly in AudioEffectFlange.voices routine:

line 105 delay_rate_incr = delay_rate / (2147483648.0 * AUDIO_SAMPLE_RATE_EXACT)

delay_rate_incr is an int type. For any normal values of delay_rate in Hz 
( i.e 0.5 Hz, as in example Sketch) , this will evaluate to
a tiny fraction which will evaluate to 0 for an integer type. 
So, BOTH of these lines should both be replaced with

delay_rate_incr =(delay_rate * 2147483648.0)/ AUDIO_SAMPLE_RATE_EXACT;

After modifying this file, the flange effect tested out properly for me.

4) Changed analyse_notefreq.cpp to allow the user to turn off processing when tuner isn't needed
by setting "enabled" var to false when threshold is set to < 0.
void AudioAnalyzeNoteFrequency::begin( float threshold ) {
    __disable_irq( );
    process_buffer = false;
    yin_threshold  = threshold;
    periodicity    = 0.0f;
    next_buffer    = true;
    running_sum    = 0;
    tau_global     = 1;
    first_run      = true;
    yin_idx        = 1;
	if (threshold > 0.0) {
		enabled = true;
	}
	else {
		enabled = false;
	}
    state          = 0;
    data           = 0.0f;
    __enable_irq( );
}

Changed pointer increment from 4 to 16 in AudioAnalyzeNoteFrequency::process   routine
to speedup the routine. This allows the guitar tuner routine to co-exist with other processing
being done by audio routines. (goes from 70% CPU utilization down to 40%)
 Change in lines 107,113,119,125 
