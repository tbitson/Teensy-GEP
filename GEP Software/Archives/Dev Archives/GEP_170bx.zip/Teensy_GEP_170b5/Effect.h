/*
   Effect class file
   sub-class this ckass for each effect

   version 1.0b0  27Jan2020

  All direct control of the TAL Effects should be done
  in this class or subclass. This will group
  the various effect controls into thier respective
  class to elimated a rogue section of code changing
  something unexpectedly . Incapsulate TAL access to
  its respective class.

  This file "Effect.h" will contain the methods that
  are common in the indiviual subclasses, as well as
  any overarching audio function will be migrated here.

*/

#ifndef EFFECT_H
#define EFFECT_H


class Effect {
  public:
    Effect();

    void toggle();
    bool getStatus();
    void process(bool);
    bool checkEncoders();

    virtual void init();
    virtual void enable();
    virtual void disable();
    virtual void convertToSlider();
    virtual void convertFromSlider();
    virtual void printConfig();
    virtual void update();
    virtual void drawScreen(bool);

    bool enabled;

    String effectName;
    int16_t selectedItem;
    int16_t lastselectedItem;
    bool itemValueChanged;
    bool selectedItemChanged;

  private:
    static const uint8_t numSliders = 2;
    float sliderVal[3];
};



Effect :: Effect()
{
  effectName = "Effect";
  selectedItem = 0;
  lastselectedItem = 0;
  itemValueChanged = false;
  selectedItemChanged = false;
}

void Effect :: init()
{  }

void Effect :: enable()
{  }

void Effect :: disable()
{  }

void Effect :: convertToSlider()
{  }

void Effect :: convertFromSlider()
{   }

void Effect :: printConfig()
{   }

void Effect :: update()
{   }

void Effect :: drawScreen(bool drawAll)
{   }



void Effect :: toggle()
{
  if (enabled)
    disable();
  else
    enable();
}


bool Effect :: getStatus()
{
  return enabled;
}






void Effect :: process(bool initScreen)
{
  selectedItemChanged = false;
  itemValueChanged = false;

  // set the sliders values to the current stored settings
  if (initScreen)
    convertToSlider();


  // allow some time for user to rotate encoders
  delay(50);

  // read encoders and check for changes
  checkEncoders();

  if (selectedItemChanged || initScreen)
  {
    drawScreen(true);
  }
  else if (itemValueChanged)
  {
    convertFromSlider();
    update();
    drawScreen(false);
    printValue("itemValueChanged", itemValueChanged);
  }


  // reset encoder values for new delta
  lastParamEncVal = paramEncVal;
  lastValEncVal = valEncVal;
}




bool Effect :: checkEncoders()
{
  // checks both param & value encoders for changes.
  // Read the param encoder first, which selects the
  // gui item. If changed, exits
  // If no changes, the value encoder
  // is read. Changes to value encoder increase or decrease
  // the value of the "selected item"

  paramEncVal = readParamEncoder() / 2;

  if (paramEncVal != lastParamEncVal)
  {
    printValue("paramEncVal", paramEncVal);
    printValue("lastParamEncVal", lastParamEncVal);

    // save the current selected item
    lastselectedItem = selectedItem;

    // and then move to next or previous item, wraps-around
    if (paramEncVal > lastParamEncVal)
      selectedItem++;
    else if (paramEncVal < lastParamEncVal)
      selectedItem--;

    selectedItem = selectedItem % numSliders;
    selectedItemChanged = true;
    printValue("selectedItem", selectedItem);
    return selectedItemChanged;
  }

  else
  {
    // if no param encoder changes, then read Value Encoder
    valEncVal = readValueEncoder() / 2;
    if (valEncVal != lastValEncVal)
    {
      // increase or decrease the slider's new position (need to re-draw later)
      if (valEncVal > lastValEncVal)
        sliderVal[selectedItem] += 4;

      else if (valEncVal < lastValEncVal)
        sliderVal[selectedItem] -= 4;

      // keep it in the slider's range
      sliderVal[selectedItem] = constrain(sliderVal[selectedItem], 0, 100.0);
      itemValueChanged = true;
      printValue("sliderVal", sliderVal[selectedItem] );
      printValue("itemValueChanged", itemValueChanged);
      return itemValueChanged;
    }
    return false;
  }
}

#endif
