/* status.h - status secreen



*/
#ifndef STATUS_H
#define STATUS_H

#include "guiItems.h"




void statusScreen(bool initScreen)
{
  uint8_t numStatusButtons = 7;
  int16_t statusButtonsX = 20;
  int16_t statusButtonsY[7] = {20, 50, 80, 110, 140, 170, 200};
  String statusLabels[7] = {"Compressor", "Reverb", "Equalizer", "Flanger", "Tremolo", "Wah-Wah", "Delayer"};
  bool status[7];

  if (initScreen)
  {
    eraseScreen();
    drawTitle("Effects Status");
  }

  status[0] = compressor.getStatus();
  status[1] = reverb.getStatus();
  status[2] = eq.getStatus();
  status[3] = flanger.getStatus();
  status[4] = tremolo.getStatus();
  status[5] = wahwah.getStatus();
  status[6] = delayer.getStatus();

  for (uint8_t i = 0; i < numStatusButtons; i++)
  {
    drawButton(statusButtonsX, statusButtonsY[i], status[i]);
    drawLabel(statusButtonsX + 20, statusButtonsY[i] - 5, statusLabels[i], false);
  }
}

#endif
