/*
    reverbScreen.h

    handles the freeverb screen drawing and updates
    the reverb settings

    version 2.0  Dec 2019

*/



#include "guiElements.h"

//#define TEST
//#define DEBUG_MODE


// prototypes
void initReverb();
void disableReverb();
void enableReverb();
void convertReverbToSliders();
void convertSlidersToReverb();
void updateReverbSettings();
void drawReverbScreen();
void checkEncoders();



// constants
#define NUM_ITEMS 3



// global vars
int16_t selectedItem = 0;
int16_t lastSelectedItem = 0;
bool selectedItemChanged = false;
bool itemValueChanged = false;
float sliderPos[NUM_ITEMS];

boolean reverbActive     = false;





void initReverb()
{
  disableReverb();
  updateReverbSettings();
}



void disableReverb()
{
  mixer1.gain(REVERB, OFF);
  reverbActive = false;
}


void enableReverb()
{
  mixer1.gain(REVERB, 1.0);
  reverbActive = true;
}



void updateReverbSettings()
{
  freeverb1.roomsize(cfg.reverbRoomsize);
  freeverb1.damping(cfg.reverbDamping);
  mixerx.gain()
}



// main reverb screen loop
void doReverbScreen()
{
  selectedItemChanged = false;
  itemValueChanged = false;

  // set the sliders values to the current stored eq settings
  if (!initialScreenDrawn)
    convertReverbToSliders();

  // read encoders and check for changes
  checkEncoders(NUM_ITEMS);

  // draw the screen
  if (selectedItemChanged || itemValueChanged || !initialScreenDrawn)
  {
    convertSlidersToReverb();
    drawReverbScreen();
    convert();
    updateReverbSettings();

    lastParamEncVal = paramEncVal;
    lastValEncVal = valEncVal;
  }
}



void convertReverbToSliders() // updateSliderValues()
{
    sliderPos[0] = cfg.reverbVolume * 100.0; // 0 to 100%
    sliderPos[1] = cfg.reverbRoomsize * 100.0;
    sliderPos[2] = cfg.reverbDamping * 100.0;
}




void convertSlidersToReverb() //  updateEqValues()
{
  cfg.reverbVolume   = sliderPos[0] / 100.0;
  cfg.reverbRoomsize = sliderPos[1] / 100.0;
  cfg.reverbDamping  = sliderPos[2] / 100.0;
}




void drawReverbScreen()
{
  // slider spacing
  uint16_t xInitial = 29;
  uint16_t xSep = 90;

  // slider x positions
  uint16_t sx[NUM_ITEMS];
  for (uint8_t i = 0; i < NUM_ITEMS; i++)
    sx[i] = i * xSep + xInitial;

  // slider y positions
  uint16_t sy = 0;

  if (!initialScreenDrawn)
  {
    Serial.println("Initializing Reverb Screen");
    selectedItem = 0;

    // reset encoders
    paramEncoder.write(0);
    valueEncoder.write(0);
    lastParamEncVal = 0;
    lastValEncVal = 0;

    // draw screen text
    tft.fillScreen(GUI_FILL_COLOR);
    tft.setTextColor(GUI_ITEM_COLOR);
    tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Volume  RoomSize   Damping");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Freeverb");
  }


  // first time we need to draw all items
  if (!initialScreenDrawn || selectedItemChanged)
  {

    for (uint8_t i = 0; i < NUM_ITEMS; i++)
    {
      if (i == selectedItem)
        drawSlider(sx[i], sy, sliderPos[i], true);
      else
        drawSlider(sx[i], sy, sliderPos[i], false);
    }
  }
  // otherwise only draw selected item
  else
    drawSlider(sx[selectedItem], sy, sliderPos[selectedItem], true);

  initialScreenDrawn = true;
}







bool checkEncoders(uint8_t numItems)
{
  // checks both param & value encoders for changes
  // read the param encoder first, which selects the
  // gui item. If changed, exits with the new
  // "selected item". If no changes, the value encoder
  // is read. Changes to value encode increase or decrease
  // the value of the "selected item"

  // store the current value as baseline and read Parameter Encoder
  lastParamEncVal = paramEncVal;
  paramEncVal = readParamEncoder();

  if (paramEncVal != lastParamEncVal)
  {
    printValue("paramEncVal", paramEncVal);
    printValue("lastParamEncVal", lastParamEncVal);

    // save the current selected item
    lastSelectedItem = selectedItem;

    // and then move to next or previous item
    if (paramEncVal > lastParamEncVal)
      selectedItem++;
    else if (paramEncVal < lastParamEncVal)
      selectedItem--;

    // make sure we stay in bounds
    selectedItem = constrain(selectedItem, 0, numItems - 1);
    printValue("selectedItem", selectedItem);

    selectedItemChanged = true;
    return true;
  }

  else

  {
    // if no param encoder changes, then read Value Encoder
    lastValEncVal = valEncVal;
    valEncVal = readValueEncoder();

    if (valEncVal != lastValEncVal)
    {
      printValue("valEncVal", valEncVal);
      printValue("lastValEncVal", lastValEncVal);

      // increase or decrease the slider's new position (need to re-draw later)
      if (valEncVal > lastValEncVal)
        sliderPos[selectedItem] += 8;

      else if (valEncVal < lastValEncVal)
        sliderPos[selectedItem] -= 8;

      // keep it in the slider's range
      sliderPos[selectedItem] = constrain(sliderPos[selectedItem], 0, 100.0);
      printValue("sliderPos[selectedItem]", sliderPos[selectedItem]);
      itemValueChanged = true;
    }
    return true;
  }

  // nothing changed
  return false;
}
