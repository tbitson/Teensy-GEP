/* super class for guitar effects
 *  
 *   version 1.0 01Jan2020
 *  
 *
 *
 */



#include "guiElements.h"


class Effect {

  public:

    int16_t selectedItem = 0;
    int16_t lastSelectedItem = 0;
    bool selectedItemChanged = false;
    bool itemValueChanged = false;
    float guiVals[];

    Effect();
    void convertValuesToUI();
    void loop();
    void drawScreen();
    void convertUIToValues();
    void updateSettings();
    bool checkEncoders(uint8_t);

  private:
    uint8_t numUIItems;
    uint16_t xOffset;
    uint16_t xSpacing;


}


Effect::Effect
{
  numUIItems = 3;
  uint16_t itemXPos[NUM_ITEMS];
  uint16_t itemYPos[NUM_ITEMS];

}



void Effect::setup()
{
  initialScreenDrawn = false;
}



void Effect::loop()
{
  selectedItemChanged = false;
  itemValueChanged = false;

  // set the sliders values to the current stored eq settings
  if (!initialScreenDrawn)
    convertValuesToUI();

  // read encoders and check for changes
  checkEncoders(NUM_ITEMS);

  // draw the screen
  if (selectedItemChanged || itemValueChanged || !initialScreenDrawn)
  {
    convertValuesToUI();
    drawScreen();
    convertUIToValues();
    updateSettings()
    lastParamEncVal = paramEncVal;
    lastValEncVal = valEncVal;
  }
}



void convertValuesToUI()
{   }




void convertUIToValues()
{   }




void drawScreen()
{
  // UI X spacing


  // UI x positions
  xSpacing = 60;
  xOffset = 20;

  for (uint8_t i = 0; i < NUM_ITEMS; i++)
    itemXPos[i] = i * xSep + xOffset;

  // UI y positions
  for (uint8_t i = 0; i < NUM_ITEMS; i++)
    uint16_t itemYPos[i] = 0;


  if (!initialScreenDrawn)
  {
    Serial.println("Initializing Screen");
    selectedItem = 0;

    // reset encoders
    paramEncoder.write(0);
    valueEncoder.write(0);
    lastParamEncVal = 0;
    lastValEncVal = 0;

    // draw full screen with text
    tft.fillScreen(GUI_FILL_COLOR);
    tft.setTextColor(GUI_ITEM_COLOR);
    tft.setFont(Arial_14);
    tft.setCursor(20, 200);
    tft.print("Test1");
    tft.setCursor(80, 200);
    tft.print("Test2");
    tft.setCursor(140, 200);
    tft.print("Test3");
    tft.setCursor(90, 220);
    tft.setTextColor(GUI_TEXT_COLOR);
    tft.print("GUI Test Panel");
  }

  // first time we need to draw all items
  if (!initialScreenDrawn || selectedItemChanged)
  {

    for (uint8_t i = 0; i < NUM_ITEMS; i++)
    {
      if (i == selectedItem)
        drawSlider(sx[i], sy, sliderPos[i], true);
      else
        drawSlider(sx[i], sy, sliderPos[i], false);
    }
  }
  // otherwise only draw selected item
  else
    drawSlider(sx[selectedItem], sy, sliderPos[selectedItem], true);

  initialScreenDrawn = true;
}







bool checkEncoders(uint8_t numItems)
{
  // checks both param & value encoders for changes
  // read the param encoder first, which selects the
  // gui item. If changed, exits with the new
  // "selected item". If no changes, the value encoder
  // is read. Changes to value encode increase or decrease
  // the value of the "selected item"

  // store the current value as baseline and read Parameter Encoder
  lastParamEncVal = paramEncVal;
  paramEncVal = readParamEncoder();

  if (paramEncVal != lastParamEncVal)
  {
    printValue("paramEncVal", paramEncVal);
    printValue("lastParamEncVal", lastParamEncVal);

    // save the current selected item
    lastSelectedItem = selectedItem;

    // and then move to next or previous item
    if (paramEncVal > lastParamEncVal)
      selectedItem++;
    else if (paramEncVal < lastParamEncVal)
      selectedItem--;

    // make sure we stay in bounds
    selectedItem = constrain(selectedItem, 0, numItems - 1);
    printValue("selectedItem", selectedItem);

    selectedItemChanged = true;
    return true;
  }

  else

  {
    // if no param encoder changes, then read Value Encoder
    lastValEncVal = valEncVal;
    valEncVal = readValueEncoder();

    if (valEncVal != lastValEncVal)
    {
      printValue("valEncVal", valEncVal);
      printValue("lastValEncVal", lastValEncVal);

      // increase or decrease the slider's new position (need to re-draw later)
      if (valEncVal > lastValEncVal)
        sliderPos[selectedItem] += 8;

      else if (valEncVal < lastValEncVal)
        sliderPos[selectedItem] -= 8;

      // keep it in the slider's range
      sliderPos[selectedItem] = constrain(sliderPos[selectedItem], 0, 100.0);
      printValue("sliderPos[selectedItem]", sliderPos[selectedItem]);
      itemValueChanged = true;
    }
    return true;
  }

  // nothing changed
  return false;
}
