/*
    patches. h - audio functions from the Teensy Audio Tool

    Paste output from the Audio Tool in this file

    version 2.0
    Dec 2019

*/



#ifndef PATCHES_H
#define PATCHES_H

// use these names in the code if you want so if config
// changes, you only have to adjust these

// mixer names
#define EFFECT_MIXER   mixer1
#define TREMOLO_MIXER  mixer2
#define MIX_MIXER      mixer3
#define DELAY_MIXER    mixer4

// mixer 1 Effects Select channel definitions
#define WAHWAH     0
#define FLANGER    1
#define TREMOLO    2
#define DELAY_CH   3

// mixer 2 tremolo input (probably wont change)
#define T_SINE_IN_CH  0
#define T_DC_IN_CH    1

// mixer 3 Effects Mix channel definitions
#define DRY_CH              0
#define WET_NO_REVERB_CH    1   // with reverb
#define WET_REVERB          2   // without reverb
//
// mixer 4 channel definitions
#define DELAY1     0
#define DELAY2     1
#define DELAY3     2
#define DELAY4     3

// mixer 5 input select
#define AUDIO_IN    0
#define TEST_TONE   1

// off or on macros
#define ZERO_GAIN   0

// ----------------------- Insert GUI Tool Output -----------------------------------

#include <Audio.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <SerialFlash.h>

// GUItool: begin automatically generated code
AudioInputI2S            i2s1;           //xy=1771.1175537109375,189
AudioSynthWaveformDc     dc2;            //xy=1779.1175537109375,327.00001525878906
AudioSynthWaveformSine   sine1;          //xy=1782.1175537109375,394
AudioSynthWaveformDc     dc1;            //xy=1782.1175537109375,453
AudioSynthWaveformSine   sine2;          //xy=1790.1175537109375,534.0000152587891
AudioEffectEnvelope      envelope1;      //xy=1937.11767578125,564.0000152587891
AudioMixer4              mixer2;         //xy=1981.1175537109375,471
AudioMixer4              mixer5;         //xy=1991.823486328125,245.8235321044922
AudioEffectDelay         delay1;         //xy=2152.1175537109375,545
AudioAnalyzePeak         peak1;          //xy=2222.1177978515625,78
AudioFilterStateVariable filter1;        //xy=2239.1177978515625,296.00001525878906
AudioAnalyzeNoteFrequency notefreq1;      //xy=2245.1177978515625,152
AudioEffectFlange        flange1;        //xy=2245.1177978515625,354.00001525878906
AudioEffectMultiply      multiply1;      //xy=2248.1177978515625,410.00001525878906
AudioMixer4              mixer4;         //xy=2330.1175537109375,547
AudioMixer4              mixer1;         //xy=2486.1177978515625,295.00001525878906
AudioEffectFreeverb      freeverb1;      //xy=2675.1177978515625,362.00001525878906
AudioMixer4              mixer3;         //xy=2758.1175537109375,214
AudioAnalyzePeak         peak2;          //xy=2927.1175537109375,131
AudioOutputI2S           i2s2;           //xy=2943.1175537109375,262
AudioConnection          patchCord1(i2s1, 0, mixer3, 0);
AudioConnection          patchCord2(i2s1, 0, mixer5, 0);
AudioConnection          patchCord3(dc2, 0, filter1, 1);
AudioConnection          patchCord4(sine1, 0, mixer2, 0);
AudioConnection          patchCord5(dc1, 0, mixer2, 1);
AudioConnection          patchCord6(sine2, envelope1);
AudioConnection          patchCord7(envelope1, 0, mixer5, 1);
AudioConnection          patchCord8(mixer2, 0, multiply1, 1);
AudioConnection          patchCord9(mixer5, 0, filter1, 0);
AudioConnection          patchCord10(mixer5, peak1);
AudioConnection          patchCord11(mixer5, notefreq1);
AudioConnection          patchCord12(mixer5, flange1);
AudioConnection          patchCord13(mixer5, 0, multiply1, 0);
AudioConnection          patchCord14(mixer5, delay1);
AudioConnection          patchCord15(delay1, 0, mixer4, 0);
AudioConnection          patchCord16(delay1, 1, mixer4, 1);
AudioConnection          patchCord17(delay1, 2, mixer4, 2);
AudioConnection          patchCord18(delay1, 3, mixer4, 3);
AudioConnection          patchCord19(filter1, 0, mixer1, 0);
AudioConnection          patchCord20(flange1, 0, mixer1, 1);
AudioConnection          patchCord21(multiply1, 0, mixer1, 2);
AudioConnection          patchCord22(mixer4, 0, mixer1, 3);
AudioConnection          patchCord23(mixer1, freeverb1);
AudioConnection          patchCord24(mixer1, 0, mixer3, 1);
AudioConnection          patchCord25(freeverb1, 0, mixer3, 2);
AudioConnection          patchCord26(mixer3, 0, i2s2, 0);
AudioConnection          patchCord27(mixer3, 0, i2s2, 1);
AudioConnection          patchCord28(mixer3, peak2);
AudioControlSGTL5000     audioShield;    //xy=1776.1175537109375,63
// GUItool: end automatically generated code

//---------------------------------------------------------------------------------------



#endif
