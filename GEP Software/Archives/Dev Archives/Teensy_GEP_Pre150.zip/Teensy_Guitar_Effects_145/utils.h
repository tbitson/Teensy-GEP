/*******************************************************************************
     TFT LCD Functions and misc utils


*******************************************************************************/



#include "ILI9341_t3.h"
#include "font_Arial.h"
#include "logo.c"


extern ILI9341_t3 tft;
extern bool msgFlag;


// display splash Screen
void splashScreen()
{
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.writeRect(80, 20, logo.width, logo.height, (uint16_t*)(logo.pixel_data));

  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(100, 100);
  tft.setFont(Arial_20);
  tft.print("Teensy");

  tft.setCursor(10, 140);
  tft.setFont(Arial_20);
  tft.print("Guitar Effects Processor");

  tft.setCursor(85, 180);
  tft.setFont(Arial_14);
  tft.print(VERSION);

  delay(5000);
}



// show message on the lcd
void tftMessage(String message)
{
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(80, 60);
  tft.setFont(Arial_16);
  tft.print(message);
  delay(1000);
  tft.fillScreen(ILI9341_BLACK);
  msgFlag = false;
}


// in work
void drawSlider(uint16_t x, uint16_t y, uint8_t position, bool focus)
{

  // x, y - starting pos
  // level - % full scale 0 - 100
  // focus = true if item selected

  uint16_t width = 29;
  uint16_t height = 192;
  uint16_t radius = 8;
  uint16_t level;

  tft.fillRoundRect( x, y, width, height, radius, ILI9341_BLUE);

  // remember, the top is 0, so need to invert
  level = (100 - position) * (height - 5) / 100;
  Serial.print("level = "); Serial.println(level);
  
  if (focus)
  {
    tft.fillRoundRect(x, level, width, 10, radius, ILI9341_RED);
    tft.fillRect(x, level + 3, width, 4, ILI9341_BLACK);
  }
  else
  {
    tft.fillRoundRect(x, level, width, 10, radius, ILI9341_YELLOW);
    tft.fillRect(x, level + 3, width, 4, ILI9341_BLACK);
  }
}


void displayAudioMemUsage()
{
  Serial.print("CPU Usage     : "); Serial.print(freeverb1.processorUsage());
  Serial.print("     max: ");          Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioProcessor: "); Serial.print(AudioProcessorUsage());
  Serial.print("  max: ");          Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioMem      : "); Serial.print(AudioMemoryUsage());
  Serial.print(" .    max: ");          Serial.println(AudioMemoryUsageMax());
  Serial.println();
}



#define RESTART_ADDR 0xE000ED0C
#define READ_RESTART() (*(volatile uint32_t *)RESTART_ADDR)
#define WRITE_RESTART(val) ((*(volatile uint32_t *)RESTART_ADDR) = (val))

void reboot_teensy()
{
  WRITE_RESTART(0x5FA0004);
}
