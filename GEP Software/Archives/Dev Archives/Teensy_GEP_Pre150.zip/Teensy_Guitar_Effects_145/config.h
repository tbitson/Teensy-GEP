/*******************************************************************************
   Global settings variables and functions to
   save and load to non-volatile memory (EEPROM)

   version 0.81


*******************************************************************************/

// prototypes
void saveConfig();
bool loadConfig();
void showConfig();
void clearEEPROM();



// if the first byte of stored data matches this, it
// is assumed valid data for this version
#define EEPROM_VERSION 145


// *** default settings NOT avaiable in GUI ***

#define HEADPHONE_OUTPUT_LEVEL 0.7
#define LINEOUT_AUDIO_LEVEL    8

// EQ bands
const float BASS_FREQUENCY       = 100;
const float MID_BASS_FREQUENCY   = 250;
const float MIDRANGE_FREQUENCY   = 600;
const float MID_TREBLE_FREQUENCY = 1300;
const float TREBLE_FREQUENCY     = 3000;

// wah-wah settings
const int WAH_WAH_CENTER_FREQ = 500;
const int WAH_WAH_GAIN        = 4;
const int WAH_WAH_OCTAVES     = 2;  // +/- 2 octaves

// flanger
const int FLANGE_DELAY_LENGTH = 8 * AUDIO_BLOCK_SAMPLES;  // x 2 to 12
const int MAX_FLANGER_DEPTH   = FLANGE_DELAY_LENGTH / 4;  // * 1 to 3
const int SIDX                = FLANGE_DELAY_LENGTH / 4;  // / 4 to 8

// more of a chorus-like effect for flanger
//const int FLANGE_DELAY_LENGTH = 12 * AUDIO_BLOCK_SAMPLES;
//const int MAX_FLANGER_DEPTH   = FLANGE_DELAY_LENGTH / 8;
//const int SIDX                = 3 * FLANGE_DELAY_LENGTH / 4;

short delayline[FLANGE_DELAY_LENGTH];




// *** settings adjustable in GUI ***

// equalizer - set for flat response
float bass        = 0.0;
float mid_bass    = 0.0;
float midrange    = 0.0;
float mid_treble  = 0.0;
float treble      = 0.0;
float maxEQ       = 0.0;

// compressor
uint8_t compressorGain      = 1;
uint8_t compressorResponse  = 3;
int32_t compressorThreshold = 17000;
int32_t compressorAttack    = 1024;
int32_t compressorDecay     = 2048;


// tremolo
float tremoloSpeed    = 3.0;
float tremoloDepth    = 0.2;

// reverb
float reverbVolume    = 0.3;
float reverbRoomsize  = 0.5;
float reverbDamping   = 0.5;


// flanger
int   flangerDepth   = FLANGE_DELAY_LENGTH / 8;
float flangerSpeed    = 0.3;   // 3.3 second sweep

// input level
int inputValueAdj = 10;


// general globals
byte vers;
byte test = 0x55;

// save at beginning of eeprom space
const uint16_t eeAddress = 0;


//------------------------------------------------------------



//  configuration structure
struct Config
{
  byte    vers;

  float   bass;
  float   mid_bass;
  float   midrange;
  float   mid_treble;
  float   treble;

  uint8_t compressorGain;
  uint8_t compressorResponse;
  int32_t compressorThreshold;
  int32_t compressorAttack;
  int32_t compressorDecay;

  float   tremoloSpeed;
  float   tremoloDepth;

  float   flangerSpeed;
  int     flangerDepth;

  float   reverbVolume;
  float   reverbRoomsize;
  float   reverbDamping;

  int     inputValueAdj;
  byte    test;               // debugging - remove

  // add:
  // current screen
  // effects switches state
};

// create globalinstance
Config  config;






void saveConfig()
{
  config.vers = EEPROM_VERSION;
  config.bass = bass;
  config.mid_bass = mid_bass;
  config.midrange = midrange;
  config.mid_treble = mid_treble;
  config.treble = treble;
  config.compressorGain = compressorGain;
  config.compressorResponse = compressorResponse;
  config.compressorThreshold = compressorThreshold;
  config.compressorAttack = compressorAttack;
  config.compressorDecay = compressorDecay;
  config.tremoloSpeed = tremoloSpeed;
  config.tremoloDepth = tremoloDepth;
  config.flangerSpeed = flangerSpeed;
  config.flangerDepth = flangerDepth;
  config.reverbVolume = reverbVolume;
  config.reverbRoomsize = reverbRoomsize;
  config.reverbDamping = reverbDamping;
  config.inputValueAdj = inputValueAdj;
  config.test = 0x55;

  EEPROM.put(eeAddress, config);
  Serial.println("Config Saved");
  showConfig();
}



bool loadConfig()
{

  uint8_t checkVers  = EEPROM.read(0);
  Serial.print("EE Version "); Serial.println(checkVers);

  if (checkVers == EEPROM_VERSION)
    Serial.println("EEPROM OK, Loading last session");
  else
  {
    Serial.println("EEPROM Invalid, using defaults");
    return false;
  }

  uint16_t  eeAddress = 0;
  EEPROM.get(eeAddress, config);

  vers = config.vers;
  bass = config.bass;
  mid_bass = config.mid_bass;
  midrange = config.midrange;
  mid_treble = config.mid_treble;
  treble = config.treble;
  compressorGain = config.compressorGain;
  compressorResponse = config.compressorResponse;
  compressorThreshold = config.compressorThreshold;
  compressorAttack = config.compressorAttack;
  compressorDecay = config.compressorDecay;
  tremoloSpeed = config.tremoloSpeed;
  tremoloDepth = config.tremoloDepth;
  flangerSpeed = config.flangerSpeed;
  flangerDepth = config.flangerDepth;
  reverbVolume = config.reverbVolume;
  reverbRoomsize = config.reverbRoomsize;
  reverbDamping = config.reverbDamping;
  inputValueAdj = config.inputValueAdj;
  byte test = config.test;

  Serial.print("test byte (0x55) = "); Serial.println(test, HEX);
  Serial.println("Config Loaded");
  
  return  true;
}


// debugging use
void showConfig()
{
  Serial.println(F("EEProm Config = "));
  Serial.print(F("vers = "));                Serial.println(vers);
  Serial.print(F("bass = "));                Serial.println(bass);
  Serial.print(F("mid_bass = "));            Serial.println(mid_bass);
  Serial.print(F("midrange = "));            Serial.println(midrange);
  Serial.print(F("mid_treble = "));          Serial.println(mid_treble);
  Serial.print(F("treble = "));              Serial.println(treble);
  Serial.print(F("compressorGain = "));      Serial.println(compressorGain);
  Serial.print(F("compressorResponse = "));  Serial.println(compressorResponse);
  Serial.print(F("compressorThreshold = ")); Serial.println(compressorThreshold);
  Serial.print(F("compressorAttack = "));    Serial.println(compressorAttack);
  Serial.print(F("compressorDecay = "));     Serial.println(compressorDecay);
  Serial.print(F("tremoloSpeed = "));        Serial.println(tremoloSpeed);
  Serial.print(F("tremoloDepth = "));        Serial.println(tremoloDepth);
  Serial.print(F("flangerSpeed = "));        Serial.println(flangerSpeed);
  Serial.print(F("flangerDepth = "));        Serial.println(flangerDepth);
  Serial.print(F("reverbVolume = "));        Serial.println(reverbVolume);
  Serial.print(F("reverbRoomsize = "));      Serial.println(reverbRoomsize);
  Serial.print(F("reverbDamping = "));       Serial.println(reverbDamping);
  Serial.print(F("inputValueAdj = "));       Serial.println(inputValueAdj);
  Serial.print(F("EOF Test = 0x"));          Serial.println(test, HEX);
  Serial.println();
}




// clear eeprom contents (dev use only so far)
void clearEEPROM()
{
  Serial.println("Clearing EEPROM...");

  for (int i = 0 ; i < EEPROM.length() ; i++)
    EEPROM.write(i, 0);

  Serial.println("done");
}
