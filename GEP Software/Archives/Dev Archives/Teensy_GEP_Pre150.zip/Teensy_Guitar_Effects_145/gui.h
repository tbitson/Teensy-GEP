
// gotta do stuff
// compressor: switch from register writes to avc function
// switch all config vars to structure or class


// external vars
extern ILI9341_t3 tft;
extern XPT2046_Touchscreen ts;
extern Encoder parameterEncoder;
extern Encoder valueEncoder;
extern Bounce compressorSwitch;
extern Bounce tunerSwitch;
extern Bounce saveSwitch;
extern PCF8574 PCF;

extern void drawSlider(uint16_t x, uint16_t y, uint16_t level, bool focus);

// filter value & gain vars
extern int eqBand_Gain[5];
extern int updateFilter[5];

extern boolean initialScreenDrawn;

// encoder & pot status values
extern long currentParamEncoder;
extern long lastParamEncoder;
extern long currentValueEncoder;
extern long lastValueEncoder;
extern uint16_t LastMixPotValue;
extern uint16_t LastWahWahPotValue;

// prototypes
void drawInitialEqScreen();
void updateEqScreen();
void drawInitialCompressorScreen();
void updateCompressorScreen();
void drawInitialTremoloScreen();
void updateTremoloScreen();
void drawInitialFlangerScreen();
void updateFlangerScreen();
void drawInitialReverbScreen();
void updateReverbScreen();
void drawInitialInputTrimScreen();
void updateInputTrimScreen();


void updateExpanderGain();
void updateExpanderResponse();
void updateCompressorThreshold();
void updateCompressorAttack();
void updateCompressorDecay();


// gui settings
#define GUI_ELEMENT_COLOR ILI9341_YELLOW
#define GUI_FOCUS_ELEMENT_COLOR ILI9341_RED

#define EQ_SCREEN          0
#define COMPRESSOR_SCREEN  1
#define TREMOLO_SCREEN     2
#define FLANGER_SCREEN     3
#define REVERB_SCREEN      4
#define TRIM_SCREEN        5






// gui globals vars
boolean eqBandChanged = false;
boolean eqValueChanged = false;

boolean tremoloValueChanged = false;
boolean tremoloScreenFocusItemChanged = false;

boolean flangerValueChanged = false;
boolean flangerScreenFocusItemChanged = false;

boolean compScreenFocusItemChanged = false;
boolean compressorValueChanged = false;
int CompressorAdjustValue;


boolean reverbScreenFocusItemChanged = false;
boolean reverbValueChanged = false;
int ReverbChanged;

int Input_TrimChanged;

int EqScreenFocusItem;
int lastEqScreenFocusItem;

int tremoloScreenFocusItem;
int lastTremoloScreenFocusItem;

int flangerScreenFocusItem;
int lastFlangerScreenFocusItem;

int compScreenFocusItem;
int lastCompScreenFocusItem;

int reverbScreenFocusItemValue[5];
int reverbScreenFocusItem;
int lastReverbScreenFocusItem;




// *** EQ Screen ***

void drawInitialEqScreen()
{
  int a;
  parameterEncoder.write(0);
  EqScreenFocusItem = 0;
  lastValueEncoder = (int)(91.0 - bass * 7.6);
  valueEncoder.write(lastValueEncoder);
  eqBand_Gain[0] = lastValueEncoder;
  a = (int)(91.0 - mid_bass * 7.6);
  eqBand_Gain[1] = a;
  a = (int)(91.0 - midrange * 7.6);
  eqBand_Gain[2] = a;
  a = (int)(91.0 - mid_treble * 7.6);
  eqBand_Gain[3] = a;
  a = (int)(91.0 - treble * 7.6);
  eqBand_Gain[4] = a;
  lastEqScreenFocusItem = -1;

  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("100      250     600    1300    3000");
  tft.setCursor(90, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Parametric EQ");

  // Draw sliders
  tft.fillRoundRect( 29, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect( 87, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(145, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(203, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(261, 0, 29, 192, 8, ILI9341_BLUE);

  // draw handles
  tft.fillRoundRect(29, eqBand_Gain[0], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
  tft.fillRect(29, eqBand_Gain[0] + 3, 29, 4, ILI9341_BLACK);
  tft.fillRoundRect(87, eqBand_Gain[1], 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(87, eqBand_Gain[1] + 3, 29, 4, ILI9341_BLACK);
  tft.fillRoundRect(145, eqBand_Gain[2], 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(145, eqBand_Gain[2] + 3, 29, 4, ILI9341_BLACK);
  tft.fillRoundRect(203, eqBand_Gain[3], 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(203, eqBand_Gain[3] + 3, 29, 4, ILI9341_BLACK);
  tft.fillRoundRect(261, eqBand_Gain[4], 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(261, eqBand_Gain[4] + 3, 29, 4, ILI9341_BLACK);
  eqBandChanged = false;
  eqValueChanged = false;
  initialScreenDrawn = true;
}



void updateEqScreen()
{
  int x;
  // first handle Parameter Encoder
  currentParamEncoder = parameterEncoder.read() >> 2;

  if (currentParamEncoder > lastParamEncoder)
  {
    lastEqScreenFocusItem = EqScreenFocusItem;
    EqScreenFocusItem++;
    EqScreenFocusItem = constrain(EqScreenFocusItem, 0, 4);
    eqBandChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if (currentParamEncoder < lastParamEncoder)
  {
    lastEqScreenFocusItem = EqScreenFocusItem;
    EqScreenFocusItem--;
    EqScreenFocusItem = constrain(EqScreenFocusItem, 0, 4);
    eqBandChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  // next handle Value Encoder
  currentValueEncoder = valueEncoder.read() >> 2;
  if (currentValueEncoder > lastValueEncoder)
  {
    eqBand_Gain[EqScreenFocusItem] -= 8;   // because bottom of slider has Y=182, top =0
    eqBand_Gain[EqScreenFocusItem] = constrain(eqBand_Gain[EqScreenFocusItem], 0, 182);
    eqValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    eqBand_Gain[EqScreenFocusItem] += 8;// because bottom of slider has Y=182, top =0
    eqBand_Gain[EqScreenFocusItem] = constrain(eqBand_Gain[EqScreenFocusItem], 0, 182);
    eqValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (eqValueChanged == true)
  {
    float z = -12.0 + ((float)(182.0 - eqBand_Gain[EqScreenFocusItem]) / 7.6);
    //Serial.println(z);

    switch (EqScreenFocusItem)
    {
      case  0:
        calcBiquad(FILTER_PARAEQ, BASS_FREQUENCY, z, 1, 524288, 44100, updateFilter);
        audioShield.eqFilter(0, updateFilter);
        bass = z;
        break;

      case  1:
        calcBiquad(FILTER_PARAEQ, MID_BASS_FREQUENCY, z, 1, 524288, 44100, updateFilter);
        audioShield.eqFilter(1, updateFilter);
        mid_bass = z;
        break;

      case  2:
        calcBiquad(FILTER_PARAEQ, MIDRANGE_FREQUENCY, z, 1, 524288, 44100, updateFilter);
        audioShield.eqFilter(2, updateFilter);
        midrange = z;
        ; break;

      case  3:
        calcBiquad(FILTER_PARAEQ, MID_TREBLE_FREQUENCY, z, 1, 524288, 44100, updateFilter);
        audioShield.eqFilter(3, updateFilter);
        mid_treble = z;
        break;

      case  4:
        calcBiquad(FILTER_PARAEQ, TREBLE_FREQUENCY, z, 1, 524288, 44100, updateFilter);
        audioShield.eqFilter(4, updateFilter);
        treble = z;
    }
  }

  if ((eqBandChanged == true) || (eqValueChanged == true))
  {
    x = 29;
    if (lastEqScreenFocusItem != -1)
    {
      switch (lastEqScreenFocusItem)
      {
        case 0: x = 29; break;
        case 1: x = 87; break;
        case 2: x = 145; break;
        case 3: x = 203; break;
        case 4: x = 261;
      }
      tft.fillRoundRect(x, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(x, eqBand_Gain[lastEqScreenFocusItem], 29, 10, 8, GUI_ELEMENT_COLOR);
      tft.fillRect(x, eqBand_Gain[lastEqScreenFocusItem] + 3, 29, 4, ILI9341_BLACK);
    }

    if (EqScreenFocusItem == 0)
    {
      tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(29, eqBand_Gain[0], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
      tft.fillRect(29, eqBand_Gain[0] + 3, 29, 4, ILI9341_BLACK);
    }

    if (EqScreenFocusItem == 1)
    {
      tft.fillRoundRect(87, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(87, eqBand_Gain[1], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
      tft.fillRect(87, eqBand_Gain[1] + 3, 29, 4, ILI9341_BLACK);
    }

    if (EqScreenFocusItem == 2)
    {
      tft.fillRoundRect(145, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(145, eqBand_Gain[2], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
      tft.fillRect(145, eqBand_Gain[2] + 3, 29, 4, ILI9341_BLACK);
    }

    if (EqScreenFocusItem == 3)
    {
      tft.fillRoundRect(203, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(203, eqBand_Gain[3], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
      tft.fillRect(203, eqBand_Gain[3] + 3, 29, 4, ILI9341_BLACK);
    }

    if (EqScreenFocusItem == 4)
    {
      tft.fillRoundRect(261, 0, 29, 192, 8, ILI9341_BLUE);
      tft.fillRoundRect(261, eqBand_Gain[4], 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
      tft.fillRect(261, eqBand_Gain[4] + 3, 29, 4, ILI9341_BLACK);
    }
    eqBandChanged = false;
    eqValueChanged = false;
  }
}



// *** Compressor Screen ***

void drawInitialCompressorScreen()
{
  int pos;
  parameterEncoder.write(0);
  compScreenFocusItem = 0;
  lastParamEncoder = 0;
  valueEncoder.write(0);
  lastValueEncoder = 0;
  lastCompScreenFocusItem = -1;
  tft.fillScreen(ILI9341_BLACK);
  tft.setFont(Arial_14);
  tft.setTextColor(ILI9341_CYAN);
  tft.setCursor(0, 200);
  tft.print("Gain");
  tft.setTextColor(ILI9341_YELLOW);
  tft.print("    Resp      Thresh Attack Decay");
  tft.setCursor(0, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("  Expander             Compressor");
  tft.drawFastVLine(130, 0, 239, ILI9341_CYAN);

  switch (compressorGain)
  {
    case 0:
      tft.fillCircle(20, 60, 10, ILI9341_RED);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(20, 60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_RED);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(20, 60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_RED);
  }

  tft.setCursor(0, 30);
  tft.print("0 dB");
  tft.setCursor(0, 90);
  tft.print("6 dB");
  tft.setCursor(0, 150);
  tft.print("12 dB");

  switch (compressorResponse)
  {
    case 0:
      tft.fillCircle(80, 40, 10, ILI9341_RED);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_RED);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_RED);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 3:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_RED);
  }

  tft.setCursor(65, 10);
  tft.print("0 ms");
  tft.setCursor(65, 60);
  tft.print("25 ms");
  tft.setCursor(65, 110);
  tft.print("50 ms");
  tft.setCursor(65, 160);
  tft.print("100 ms");

  // Draw 3 pots
  pos = 182 - (int)((float)compressorThreshold * 0.002777);  // scale 0->65535 into  182 ->0
  tft.fillRoundRect(145, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(145, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(145, pos + 3, 29, 4, ILI9341_BLACK);

  pos = 182 - ((int)((float)compressorAttack * 0.1777));   // scale 0->1024 into 182 ->0
  tft.fillRoundRect(203, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(203, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(203, pos + 3, 29, 4, ILI9341_BLACK);

  pos = 182 - ((int)((float)compressorDecay * 0.0888));   // scale 0->2048 into 182 ->0
  tft.fillRoundRect(261, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(261, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(261, pos + 3, 29, 4, ILI9341_BLACK);
  compScreenFocusItemChanged = false;
  compressorValueChanged = false;
  initialScreenDrawn = true;
}



void updateCompressorScreen()
{
  // First handle parameter encoder changes
  currentParamEncoder = parameterEncoder.read() >> 2;
  if (currentParamEncoder > lastParamEncoder)
  {
    lastCompScreenFocusItem = compScreenFocusItem;
    compScreenFocusItem++;
    compScreenFocusItem = constrain(compScreenFocusItem, 0, 4);
    compScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if (currentParamEncoder < lastParamEncoder)
  {
    lastCompScreenFocusItem = compScreenFocusItem;
    compScreenFocusItem--;
    compScreenFocusItem = constrain(compScreenFocusItem, 0, 4);
    compScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if (compScreenFocusItemChanged == true)
  {
    switch (compScreenFocusItem)
    {
      case 0:
        tft.setTextColor(ILI9341_CYAN);
        tft.setCursor(0, 200);
        tft.print("Gain");
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("    Resp      Thresh Attack Decay");
        break;

      case 1:
        tft.setCursor(0, 200);
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Gain");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("    Resp");
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("      Thresh Attack Decay");
        break;

      case 2:
        tft.setCursor(0, 200);
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Gain    Resp");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("      Thresh ");
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Attack Decay");
        break;

      case 3:
        tft.setCursor(0, 200);
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Gain    Resp      Thresh ");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("Attack ");
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Decay");
        break;

      case 4:
        tft.setCursor(0, 200);
        tft.setTextColor(ILI9341_YELLOW);
        tft.print("Gain    Resp      Thresh Attack ");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("Decay");
        break;
    }
    compScreenFocusItemChanged = false;
  }

  // Next handle Value encoder changes
  currentValueEncoder = valueEncoder.read() >> 2;
  if (currentValueEncoder > lastValueEncoder)
  {
    CompressorAdjustValue = 1;
    compressorValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    CompressorAdjustValue = -1;
    compressorValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (compressorValueChanged == true)
  {
    switch (compScreenFocusItem)
    {
      case  0: updateExpanderGain(); break;
      case  1: updateExpanderResponse(); break;
      case  2: updateCompressorThreshold(); break;
      case  3: updateCompressorAttack(); break;
      case  4: updateCompressorDecay();
    }
    compressorValueChanged = false;
  }
}



void updateExpanderGain()
{
  compressorGain += CompressorAdjustValue;
  compressorGain = constrain(compressorGain, 0, 2);
  switch (compressorGain) {
    case 0:
      tft.fillCircle(20,  60, 10, ILI9341_RED);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(20,  60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_RED);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(20,  60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_RED);
  }
  audioShield.modify(DAP_AVC_CTRL, compressorGain << 12, 0x3000);
#ifdef DEBUG_MODE
  Serial.print(compressorGain);
#endif
}



void updateExpanderResponse()
{
  compressorResponse += CompressorAdjustValue;
  compressorResponse = constrain(compressorResponse, 0, 3);

  switch (compressorResponse)
  {
    case 0:
      tft.fillCircle(80,  40, 10, ILI9341_RED);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_RED);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_RED);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 3:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_RED);
  }
  audioShield.modify(DAP_AVC_CTRL, compressorResponse << 8, 0x0300);
#ifdef DEBUG_MODE
  Serial.print(compressorResponse);
#endif
}



void updateCompressorThreshold()
{
  int pos;
  compressorThreshold += CompressorAdjustValue * 1000;
  compressorThreshold = constrain(compressorThreshold, 0, 65535);
  pos = 182 - (int) ((float) compressorThreshold * 0.002777); // scale 0->65535 into  182 ->0
  tft.fillRoundRect(145, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(145, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(145, pos + 3, 29, 4, ILI9341_BLACK);
  audioShield.write(DAP_AVC_THRESHOLD, compressorThreshold);
#ifdef DEBUG_MODE
  Serial.println("Compressor Threshold");
#endif
}



void updateCompressorAttack()
{
  int pos;
  compressorAttack += CompressorAdjustValue * 16;
  compressorAttack = constrain(compressorAttack, 0, 1024);   // use only 1/4 of 12-bit range of SGTL5000 (about 800 dB/sec)
  pos = 182 - ((int)((float)compressorAttack * 0.1777));  // scale 0->1024 into 182 ->0
  tft.fillRoundRect(203, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(203, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(203, pos + 3, 29, 4, ILI9341_BLACK);
  audioShield.write(DAP_AVC_ATTACK, compressorAttack);
#ifdef DEBUG_MODE
  Serial.println(compressorAttack);
#endif
}


void updateCompressorDecay()
{
  int pos;
  compressorDecay += CompressorAdjustValue * 32;
  compressorDecay = constrain(compressorDecay, 0, 2048);   // use only 1/2 of 12-bit range of SGTL5000 (about 100 dB/sec)
  pos = 182 - ((int)((float)compressorDecay * 0.0888));   // scale 0->2048 into 182 ->0
  tft.fillRoundRect(261, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(261, pos, 29, 10, 8, ILI9341_YELLOW);
  tft.fillRect(261, pos + 3, 29, 4, ILI9341_BLACK);
  audioShield.write(DAP_AVC_DECAY, compressorDecay);
#ifdef DEBUG_MODE
  Serial.println(compressorDecay);
#endif
}






// *** Tremolo Screen ***

void drawInitialTremoloScreen()
{
  int pos;
  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Speed   Depth");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Tremolo");

  // Draw 2 Sliders
  tremoloSpeed = constrain(tremoloSpeed, 0.5, 8);
  sine1.frequency(tremoloSpeed);

  pos = 194 - (int)((tremoloSpeed * 24.0)); //scale 0.5 -> 8 into 182 -> 0
  tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
  tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
  tremoloDepth = constrain(tremoloDepth, 0, 0.6);
  sine1.amplitude(tremoloDepth);

  pos = 182 - (int)(tremoloDepth * 300.0);
  tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
  lastTremoloScreenFocusItem = -1;
  tremoloValueChanged = false;
  tremoloScreenFocusItemChanged = false;
  initialScreenDrawn = true;
}





void updateTremoloScreen()
{
  int pos;
  // first handle Parameter Encoder
  currentParamEncoder = parameterEncoder.read() >> 2;
  if (currentParamEncoder > lastParamEncoder)
  {
    lastTremoloScreenFocusItem = tremoloScreenFocusItem;
    tremoloScreenFocusItem++;
    tremoloScreenFocusItem = tremoloScreenFocusItem & 1;
    tremoloScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if (currentParamEncoder < lastParamEncoder)
  {
    lastTremoloScreenFocusItem = tremoloScreenFocusItem;
    tremoloScreenFocusItem--;
    tremoloScreenFocusItem = tremoloScreenFocusItem & 1;
    tremoloScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if ((lastTremoloScreenFocusItem != -1) && (tremoloScreenFocusItemChanged == true))
  {
    switch (lastTremoloScreenFocusItem)
    {
      case 0:
        pos = 194 - (int)((tremoloSpeed * 24.0)); //scale 0.5 -> 8 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

        pos = 182 - (int)(tremoloDepth * 300.0);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        pos = 182 - (int)(tremoloDepth * 300.0);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);

        pos = 194 - (int)((tremoloSpeed * 24.0)); //scale 0.5 -> 8 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
    }
    tremoloScreenFocusItemChanged = false;
  }

  // next handle Value Encoder
  currentValueEncoder = valueEncoder.read() >> 2;
  if (currentValueEncoder > lastValueEncoder)
  {
    switch (tremoloScreenFocusItem)
    {
      case 0:
        tremoloSpeed += 0.2;
        tremoloSpeed = constrain(tremoloSpeed, 0.5, 8);
        sine1.frequency(tremoloSpeed);
        pos = 194 - (int)((tremoloSpeed * 24.0)); //scale 0.5 -> 8 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        tremoloDepth += 0.02;
        tremoloDepth = constrain(tremoloDepth, 0, 0.6);
        sine1.amplitude(tremoloDepth);
        pos = 182 - (int)(tremoloDepth * 300.0);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }
    tremoloValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    switch (tremoloScreenFocusItem)
    {
      case 0:
        tremoloSpeed -= 0.2;
        tremoloSpeed = constrain(tremoloSpeed, 0.5, 8);
        sine1.frequency(tremoloSpeed);
        pos = 194 - (int)((tremoloSpeed * 24.0)); //scale 0.5 -> 8 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        tremoloDepth -= 0.02;
        tremoloDepth = constrain(tremoloDepth, 0, 0.6);
        sine1.amplitude(tremoloDepth);
        pos = 181 - (int)(tremoloDepth * 300.0);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }
    tremoloValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }
}



// *** Flanger Screen ***

void drawInitialFlangerScreen()
{
  int pos;
  float sf;
  int ofs;
  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Speed   Depth");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Flanger");
  // Draw 2 Sliders
  flangerSpeed = constrain(flangerSpeed, 0.15, 1);
  pos = 214 - (int)((flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
  tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
  tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

  flangerDepth = constrain(flangerDepth, 48, MAX_FLANGER_DEPTH);
  sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
  ofs = 182 + (int)(48 * sf);
  pos = ofs - (int)(flangerDepth * sf);
  tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
  lastFlangerScreenFocusItem = -1;
  flangerValueChanged = false;
  flangerScreenFocusItemChanged = false;
  initialScreenDrawn = true;
  flange1.voices(SIDX, flangerDepth, flangerSpeed);
}





void updateFlangerScreen()
{
  int pos;
  float sf;
  int ofs;
  // first handle Parameter Encoder
  currentParamEncoder = parameterEncoder.read() >> 2;
  if (currentParamEncoder > lastParamEncoder)
  {
    lastFlangerScreenFocusItem = flangerScreenFocusItem;
    flangerScreenFocusItem++;
    flangerScreenFocusItem = flangerScreenFocusItem & 1;
    flangerScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if (currentParamEncoder < lastParamEncoder)
  {
    lastFlangerScreenFocusItem = flangerScreenFocusItem;
    flangerScreenFocusItem--;
    flangerScreenFocusItem = flangerScreenFocusItem & 1;
    flangerScreenFocusItemChanged = true;
    lastParamEncoder = currentParamEncoder;
  }

  if ((lastFlangerScreenFocusItem != -1) && (flangerScreenFocusItemChanged == true))
  {
    switch (lastFlangerScreenFocusItem)
    {
      case 0:
        flangerSpeed = constrain(flangerSpeed, 0.15, 1);
        pos = 214 - (int)((flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

        flangerDepth = constrain(flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        flangerDepth = constrain(flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 181 + (int)(48 * sf);
        pos = ofs - (int)(flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);

        flangerSpeed = constrain(flangerSpeed, 0.15, 1);
        pos = 214 - (int)((flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
    }
  }

  flangerScreenFocusItemChanged = false;
  // next handle Value Encoder
  currentValueEncoder = valueEncoder.read() >> 2;

  if (currentValueEncoder > lastValueEncoder)
  {
    switch (flangerScreenFocusItem)
    {
      case 0:
        flangerSpeed *= 1.1;
        flangerSpeed = constrain(flangerSpeed, 0.15, 1);
        pos = 214 - (int)((flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        flangerDepth += 10;
        flangerDepth = constrain(flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }

    flangerValueChanged = true;
    lastValueEncoder = currentValueEncoder;
    flange1.voices(SIDX, flangerDepth, flangerSpeed);
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    switch (flangerScreenFocusItem)
    {
      case 0:
        flangerSpeed *= 0.9;
        flangerSpeed = constrain(flangerSpeed, 0.15, 1);
        pos = 214 - (int)((flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        flangerDepth -= 10;
        flangerDepth = constrain(flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }
    flangerValueChanged = true;
    lastValueEncoder = currentValueEncoder;
    flange1.voices(SIDX, flangerDepth, flangerSpeed);
  }
}


// *** Reverb Screen ***

// in work settings
// void fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t bevel, uint16_t color);
// void drawSlider(uint16_t x, uint16_t y, uint8_t level, bool focus)
uint16_t sep = 90;
uint16_t s1x = 29;
uint16_t s2x = s1x + sep;
uint16_t s3x = s2x + sep;
float sf = 182.0;

void drawInitialReverbScreen()
{
  uint8_t position;

  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Volume  RoomSize   Damping");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Freeverb");

  // Draw the 3 Sliders
  position = (uint8_t)(reverbVolume * 100.); // 0 to 100%  
  drawSlider(s1x, 0, position, true);

  position = (uint8_t)(reverbRoomsize * 100.0);
  drawSlider(s2x, 0, position, false);

  position = (uint8_t)(reverbDamping * 100.0);
  drawSlider(s3x, 0, position, false);

  initialScreenDrawn = true;
}



// using updated gui stuff, in work
void updateReverbScreen()
{
  uint8_t position;
  float value = 0;

  reverbValueChanged = false;
  reverbScreenFocusItemChanged = false;

  // first read Parameter Encoder to select item
  currentParamEncoder = parameterEncoder.read() / 8;

  if (currentParamEncoder != lastParamEncoder)
  {
    lastReverbScreenFocusItem = reverbScreenFocusItem;
    if (currentParamEncoder > lastParamEncoder)
      if (reverbScreenFocusItem < 2)
      {
        reverbScreenFocusItem++;
        reverbScreenFocusItemChanged = true;
        lastParamEncoder = currentParamEncoder;
      }

    if (currentParamEncoder < lastParamEncoder)
      if (reverbScreenFocusItem > 0)
      {
        reverbScreenFocusItem--;
        reverbScreenFocusItemChanged = true;
        lastParamEncoder = currentParamEncoder;
      }
  }


  // read value encoder to update slider value
  currentValueEncoder = valueEncoder.read() >> 2;

  // did the value change?
  if (currentValueEncoder > lastValueEncoder)
  {
    value = 0.02;
    reverbValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    value = -0.02;
    reverbValueChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  // now, update the correct slider's value
  if (reverbScreenFocusItem == 0)
  {
    reverbVolume += value;
    reverbVolume = constrain(reverbVolume, 0, 1.0);
  }
  else if (reverbScreenFocusItem == 1)
  {
    reverbRoomsize += value;
    reverbRoomsize = constrain(reverbRoomsize, 0, 1.0);
  }
  else  if (reverbScreenFocusItem == 2)
  {
    reverbDamping += value;
    reverbDamping = constrain(reverbDamping, 0, 1.0);
  }


  // update screen with selected slider and new value
  if (reverbScreenFocusItemChanged || reverbValueChanged)
  {
    Serial.print("reverbScreenFocusItem = "); Serial.println(reverbScreenFocusItem);
    Serial.print("reverbVolume = "); Serial.println(reverbVolume);
    Serial.print("reverbRoomsize = "); Serial.println(reverbRoomsize);
    Serial.print("reverbScreenFocusItem = "); Serial.println(reverbDamping);

    position = (uint8_t)(reverbVolume * 100.0); // 0 to 100%
    drawSlider(s1x, 0, position, reverbScreenFocusItem == 0);

    position = (uint8_t)(reverbRoomsize * 100.0);
    drawSlider(s2x, 0, position, reverbScreenFocusItem == 1);

    position = (uint8_t)(reverbDamping * 100.0);
    drawSlider(s3x, 0, position, reverbScreenFocusItem == 2);

    mixer1.gain(2, reverbVolume);
    freeverb1.roomsize(reverbRoomsize);
    freeverb1.damping(reverbDamping);
  }

  reverbScreenFocusItemChanged = false;
  reverbValueChanged = false;
}




// *** Input Screen ***

void drawInitialInputTrimScreen()
{
  int pos;
  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Input Level Adjust");

  // Draw 1 Slider
  inputValueAdj = constrain(inputValueAdj, 0, 15);
  pos = 182 - inputValueAdj * 12; //scale 0 -> 15 into 182 -> 0
  tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
  tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

  // draw outline around Vu Meter
  tft.drawRect(148, 0, 35, 190, ILI9341_WHITE);
  Input_TrimChanged = false;
  initialScreenDrawn = true;

  // determine max EQ band db- use for safe input level determination during input level metering
  maxEQ = 0;

  if (bass > maxEQ)
    maxEQ = bass;

  if (mid_bass > maxEQ)
    maxEQ = mid_bass;

  if (midrange > maxEQ)
    maxEQ = midrange;

  if (mid_treble > maxEQ)
    maxEQ = mid_treble;

  if (treble > maxEQ)
    maxEQ = treble;
}


void updateInputTrimScreen()
{
  int pos;

  //  handle Value Encoder
  currentValueEncoder = valueEncoder.read() >> 2;
  if (currentValueEncoder > lastValueEncoder)
  {
    inputValueAdj += 1;
    inputValueAdj = constrain(inputValueAdj, 0, 15);
    pos = 182 - inputValueAdj * 12;  //scale 0 -> 15 into 182 -> 0
    tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
    tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
    tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
    audioShield.lineInLevel(inputValueAdj);
    Input_TrimChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (currentValueEncoder < lastValueEncoder)
  {
    inputValueAdj -= 1;
    inputValueAdj = constrain(inputValueAdj, 0, 15);
    pos = 182 - inputValueAdj * 12;  //scale 0 -> 15 into 182 -> 0
    tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
    tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
    tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
    audioShield.lineInLevel(inputValueAdj);
    Input_TrimChanged = true;
    lastValueEncoder = currentValueEncoder;
  }

  if (peak1.available())
  {
    int Vu_Color;
    int Vu_Height;
    float Vu;

    Vu = peak1.readPeakToPeak();
    Vu = Vu  * exp10(maxEQ / 20.0);    // ADJUST FOR MAX EQ SETTING AS A SAFETY FACTOR IN PREVENTING OVERLOAD
    if (Vu > 0)
    {
      Vu_Height = (int)((1.0 + log(Vu)) * 90.0); // convert to a VU-style logarithmic readout
      Vu_Height = constrain(Vu_Height, 0, 182);

      if (Vu_Height < 90)
        Vu_Color = ILI9341_GREEN;
      if (Vu_Height > 90)
        Vu_Color = ILI9341_YELLOW;
      if (Vu_Height > 140)
        Vu_Color = ILI9341_RED;

      tft.fillRoundRect(150, 2, 29, 184 - Vu_Height, 4, ILI9341_BLACK);
      tft.fillRoundRect(150, 184 - Vu_Height, 29, Vu_Height, 4, Vu_Color);
    }
  }
}
