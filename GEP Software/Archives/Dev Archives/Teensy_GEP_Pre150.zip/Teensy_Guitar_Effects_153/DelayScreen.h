/*
    Delay. h - code to implement the multi-channel delay


    version 0
    Dec 2019

    just a placeholder for now

    Notes:
    add 4 delays
    add 1 mixer
    have 4 delay & 4 volume sliders
    enable button

*/


// prototype
void initDelay();
void disableDelay();
void enableDelay();


//#include "config.h"
#include "guiElements.h"


// global vars
bool delayActive;



void initDelay()
{
  disableDelay();
}


void enableDelay()
{
  delayActive = true;
}



void disableDelay()
{
  delayActive = false;
}
