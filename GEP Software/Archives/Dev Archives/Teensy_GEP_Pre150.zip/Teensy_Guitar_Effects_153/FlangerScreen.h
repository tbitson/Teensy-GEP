/*
    Flanger. h - code to implement the Flanger effect

    version 2.0B1
    Dec 2019



*/


//#include "config.h"
#include "guiElements.h"


// prototype
void initFlanger();
void disableFlanger();
void enableFlanger();
void drawInitialFlangerScreen();
void updateFlangerScreen();



// global vars
boolean flangerActive    = false;





void initFlanger()
{
  disableFlanger();

  // start flanger
  flange1.begin(delayline, FLANGE_DELAY_LENGTH, SIDX, cfg.flangerDepth, cfg.flangerSpeed);
}



void disableFlanger()
{
  mixer1.gain(FLANGER, OFF);
  flange1.voices(0, 0, 0);
  flangerActive = false;
}



void enableFlanger()
{
  flange1.voices(SIDX, cfg.flangerDepth, cfg.flangerSpeed);
  mixer1.gain(FLANGER, 1.0);
  flangerActive = true;
}





void drawInitialFlangerScreen()
{
  int pos;
  float sf;
  int ofs;
  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Speed   Depth");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Flanger");

  // Draw 2 Sliders
  cfg.flangerSpeed = constrain(cfg.flangerSpeed, 0.15, 1);
  pos = 214 - (int)((cfg.flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0

  tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
  tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

  cfg.flangerDepth = constrain(cfg.flangerDepth, 48, MAX_FLANGER_DEPTH);
  sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
  ofs = 182 + (int)(48 * sf);
  pos = ofs - (int)(cfg.flangerDepth * sf);
  tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
  tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
  tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);

  lastFlangerScreenFocusItem = -1;
  flangerValueChanged = false;
  flangerScreenFocusItemChanged = false;
  initialScreenDrawn = true;
  flange1.voices(SIDX, cfg.flangerDepth, cfg.flangerSpeed);
}





void updateFlangerScreen()
{
  int pos;
  float sf;
  int ofs;


  // first handle Parameter Encoder
  paramEncVal = paramEncoder.read() >> 2;
  if (paramEncVal > lastParamEncVal)
  {
    lastFlangerScreenFocusItem = flangerScreenFocusItem;
    flangerScreenFocusItem++;
    flangerScreenFocusItem = flangerScreenFocusItem & 1;
    flangerScreenFocusItemChanged = true;
    lastParamEncVal = paramEncVal;
  }

  if (paramEncVal < lastParamEncVal)
  {
    lastFlangerScreenFocusItem = flangerScreenFocusItem;
    flangerScreenFocusItem--;
    flangerScreenFocusItem = flangerScreenFocusItem & 1;
    flangerScreenFocusItemChanged = true;
    lastParamEncVal = paramEncVal;
  }

  if ((lastFlangerScreenFocusItem != -1) && (flangerScreenFocusItemChanged == true))
  {
    switch (lastFlangerScreenFocusItem)
    {
      case 0:
        cfg.flangerSpeed = constrain(cfg.flangerSpeed, 0.15, 1);
        pos = 214 - (int)(cfg.flangerSpeed * 214.0); //scale 0.15 -> 1 into 182 -> 0

        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);

        cfg.flangerDepth = constrain(cfg.flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(cfg.flangerDepth * sf);

        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        cfg.flangerDepth = constrain(cfg.flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 181 + (int)(48 * sf);
        pos = ofs - (int)(cfg.flangerDepth * sf);

        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);

        cfg.flangerSpeed = constrain(cfg.flangerSpeed, 0.15, 1);
        pos = 214 - (int)((cfg.flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0

        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
    }
  }

  flangerScreenFocusItemChanged = false;
  // next handle Value Encoder
  valEncVal = valueEncoder.read() >> 2;

  if (valEncVal > lastValEncVal)
  {
    switch (flangerScreenFocusItem)
    {
      case 0:
        cfg.flangerSpeed *= 1.1;
        cfg.flangerSpeed = constrain(cfg.flangerSpeed, 0.15, 1);
        pos = 214 - (int)((cfg.flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        cfg.flangerDepth += 10;
        cfg.flangerDepth = constrain(cfg.flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(cfg.flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }

    flangerValueChanged = true;
    lastValEncVal = valEncVal;
    flange1.voices(SIDX, cfg.flangerDepth, cfg.flangerSpeed);
  }

  if (valEncVal < lastValEncVal)
  {
    switch (flangerScreenFocusItem)
    {
      case 0:
        cfg.flangerSpeed *= 0.9;
        cfg.flangerSpeed = constrain(cfg.flangerSpeed, 0.15, 1);
        pos = 214 - (int)((cfg.flangerSpeed * 214.0)); //scale 0.15 -> 1 into 182 -> 0
        tft.fillRoundRect(29, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(29, pos + 3, 29, 4, ILI9341_BLACK);
        break;

      case 1:
        cfg.flangerDepth -= 10;
        cfg.flangerDepth = constrain(cfg.flangerDepth, 48, MAX_FLANGER_DEPTH);
        sf = 182.0 / (float)(MAX_FLANGER_DEPTH - 48);
        ofs = 182 + (int)(48 * sf);
        pos = ofs - (int)(cfg.flangerDepth * sf);
        tft.fillRoundRect(100, 0, 29, 192, 8, ILI9341_BLUE);
        tft.fillRoundRect(100, pos, 29, 10, 8, GUI_FOCUS_ELEMENT_COLOR);
        tft.fillRect(100, pos + 3, 29, 4, ILI9341_BLACK);
    }
    flangerValueChanged = true;
    lastValEncVal = valEncVal;
    flange1.voices(SIDX, cfg.flangerDepth, cfg.flangerSpeed);
  }
}
