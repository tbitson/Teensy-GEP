/*
    patches. h - audio functions from the Teensy Audio Tool

    Paste output from the Audio Tool in this file

    version 2.0
    Dec 2019



*/

#ifndef PATCHES_H
#define PATCHES_H

// mixer 1 channel definitions
#define REVERB  0
#define TREMOLO 1
#define WAHWAH  2
#define FLANGER 3

// mixer 3 channel definitions
#define DRY     0
#define WET     1


// the following patchboard is for the 'freeverb' version with the "test note"

// GUItool: begin automatically generated code
AudioInputI2S            i2s1;           //xy=99,200
AudioSynthWaveformSine   sine1;          //xy=99,446
AudioSynthWaveformDc     dc1;            //xy=99,509
AudioSynthWaveformDc     dc2;            //xy=102,371
AudioSynthWaveformSine   sine2;          //xy=104,641
AudioMixer4              mixer2;         //xy=299,548
AudioAnalyzePeak         peak1;          //xy=379,39
AudioAnalyzeNoteFrequency notefreq1;      //xy=379,100
AudioEffectFlange        flange1;        //xy=474,341
AudioEffectFreeverb      freeverb1;      //xy=475,217
AudioFilterStateVariable filter1;        //xy=475,279
AudioEffectMultiply      multiply1;      //xy=476,415
AudioMixer4              mixer1;         //xy=863,297
AudioEffectEnvelope      envelope1;      //xy=910,633
AudioMixer4              mixer3;         //xy=1059,173
AudioOutputI2S           i2s2;           //xy=1270,176
AudioConnection          patchCord1(i2s1, 0, multiply1, 0);
AudioConnection          patchCord2(i2s1, 0, flange1, 0);
AudioConnection          patchCord3(i2s1, 0, notefreq1, 0);
AudioConnection          patchCord4(i2s1, 0, peak1, 0);
AudioConnection          patchCord5(i2s1, 0, filter1, 0);
AudioConnection          patchCord6(i2s1, 0, freeverb1, 0);
AudioConnection          patchCord7(i2s1, 0, mixer3, 0);
AudioConnection          patchCord8(sine1, 0, mixer2, 0);
AudioConnection          patchCord9(dc1, 0, mixer2, 1);
AudioConnection          patchCord10(dc2, 0, filter1, 1);
AudioConnection          patchCord11(sine2, envelope1);
AudioConnection          patchCord12(mixer2, 0, multiply1, 1);
AudioConnection          patchCord13(flange1, 0, mixer1, 3);
AudioConnection          patchCord14(freeverb1, 0, mixer1, 0);
AudioConnection          patchCord15(filter1, 0, mixer1, 2);
AudioConnection          patchCord16(multiply1, 0, mixer1, 1);
AudioConnection          patchCord17(mixer1, 0, mixer3, 1);
AudioConnection          patchCord18(envelope1, 0, mixer3, 2);
AudioConnection          patchCord19(mixer3, 0, i2s2, 0);
AudioConnection          patchCord20(mixer3, 0, i2s2, 1);
AudioControlSGTL5000     audioShield;    //xy=118,712
// GUItool: end automatically generated code

/*

// GUItool: begin automatically generated code
AudioInputI2S            i2s1;           //xy=183,237
AudioSynthWaveformSine   sine1;          //xy=183,483
AudioSynthWaveformDc     dc1;            //xy=183,546
AudioSynthWaveformDc     dc2;            //xy=186,408
AudioMixer4              mixer2;         //xy=383,585
AudioAnalyzePeak         peak1;          //xy=463,76
AudioAnalyzeNoteFrequency notefreq1;      //xy=463,137
AudioEffectFlange        flange1;        //xy=558,378
AudioEffectFreeverb      freeverb1;      //xy=559,254
AudioFilterStateVariable filter1;        //xy=559,316
AudioEffectMultiply      multiply1;      //xy=560,452
AudioMixer4              mixer1;         //xy=947,334
AudioMixer4              mixer3;         //xy=1143,210
AudioOutputI2S           i2s2;           //xy=1382,317
AudioConnection          patchCord1(i2s1, 0, multiply1, 0);
AudioConnection          patchCord2(i2s1, 0, flange1, 0);
AudioConnection          patchCord3(i2s1, 0, notefreq1, 0);
AudioConnection          patchCord4(i2s1, 0, peak1, 0);
AudioConnection          patchCord5(i2s1, 0, filter1, 0);
AudioConnection          patchCord6(i2s1, 0, freeverb1, 0);
AudioConnection          patchCord7(i2s1, 0, mixer3, 0);
AudioConnection          patchCord8(sine1, 0, mixer2, 0);
AudioConnection          patchCord9(dc1, 0, mixer2, 1);
AudioConnection          patchCord10(dc2, 0, filter1, 1);
AudioConnection          patchCord11(mixer2, 0, multiply1, 1);
AudioConnection          patchCord12(flange1, 0, mixer1, 3);
AudioConnection          patchCord13(freeverb1, 0, mixer1, 0);
AudioConnection          patchCord14(filter1, 0, mixer1, 2);
AudioConnection          patchCord15(multiply1, 0, mixer1, 1);
AudioConnection          patchCord16(mixer1, 0, mixer3, 1);
AudioConnection          patchCord17(mixer3, 0, i2s2, 0);
AudioConnection          patchCord18(mixer3, 0, i2s2, 1);
AudioControlSGTL5000     audioShield;    //xy=225,722
// GUItool: end automatically generated code
*/
#endif
