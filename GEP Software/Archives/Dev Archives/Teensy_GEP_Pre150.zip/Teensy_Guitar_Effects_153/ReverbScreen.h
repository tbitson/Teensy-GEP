/*
    Reverb. h - code for the reverb effect

    version: FreeVerb 1.0B23
    Dec 2019



*/


#include "guiElements.h"



// prototypes
void initReverb();
void disableReverb();
void enableReverb();
void updateReverbSettings();
void drawInitialReverbScreen();
void updateReverbScreen();



// global vars
boolean reverbActive     = false;





void initReverb()
{
  disableReverb();
  updateReverbSettings();
}



void disableReverb()
{
  mixer1.gain(REVERB, OFF);
  reverbActive = false;
}


void enableReverb()
{
  mixer1.gain(REVERB, 1.0);
  reverbActive = true;
}



void updateReverbSettings()
{
  freeverb1.roomsize(cfg.reverbRoomsize);
  freeverb1.damping(cfg.reverbDamping);
}





// in work settings
// void fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t bevel, uint16_t color);
// void drawSlider(uint16_t x, uint16_t y, uint8_t level, bool focus)
uint16_t sep = 90;
uint16_t s1x = 29;
uint16_t s2x = s1x + sep;
uint16_t s3x = s2x + sep;
float sf = 182.0;




void drawInitialReverbScreen()
{
  uint8_t position;

  tft.fillScreen(ILI9341_BLACK);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setFont(Arial_14);
  tft.setCursor(20, 200);
  tft.print("Volume  RoomSize   Damping");
  tft.setCursor(120, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("Freeverb");

  // Draw the 3 Sliders
  position = (uint8_t)(cfg.reverbVolume * 100.); // 0 to 100%
  drawSlider(s1x, 0, position, true);

  position = (uint8_t)(cfg.reverbRoomsize * 100.0);
  drawSlider(s2x, 0, position, false);

  position = (uint8_t)(cfg.reverbDamping * 100.0);
  drawSlider(s3x, 0, position, false);

  initialScreenDrawn = true;
}



// using updated gui stuff, in work
void updateReverbScreen()
{
  uint8_t position;
  float value = 0;

  reverbValueChanged = false;
  reverbScreenFocusItemChanged = false;

  // first read Parameter Encoder to select item
  paramEncVal = paramEncoder.read() / 8;

  if (paramEncVal != lastParamEncVal)
  {
    lastReverbScreenFocusItem = reverbScreenFocusItem;
    if (paramEncVal > lastParamEncVal)
      if (reverbScreenFocusItem < 2)
      {
        reverbScreenFocusItem++;
        reverbScreenFocusItemChanged = true;
        lastParamEncVal = paramEncVal;
      }

    if (paramEncVal < lastParamEncVal)
      if (reverbScreenFocusItem > 0)
      {
        reverbScreenFocusItem--;
        reverbScreenFocusItemChanged = true;
        lastParamEncVal = paramEncVal;
      }
  }


  // read value encoder to update slider value
  valEncVal = valueEncoder.read() >> 2;

  // did the value change?
  if (valEncVal > lastValEncVal)
  {
    value = 0.02;
    reverbValueChanged = true;
    lastValEncVal = valEncVal;
  }

  if (valEncVal < lastValEncVal)
  {
    value = -0.02;
    reverbValueChanged = true;
    lastValEncVal = valEncVal;
  }

  // now, update the correct slider's value
  if (reverbScreenFocusItem == 0)
  {
    cfg.reverbVolume += value;
    cfg.reverbVolume = constrain(cfg.reverbVolume, 0, 1.0);
  }
  else if (reverbScreenFocusItem == 1)
  {
    cfg.reverbRoomsize += value;
    cfg.reverbRoomsize = constrain(cfg.reverbRoomsize, 0, 1.0);
  }
  else  if (reverbScreenFocusItem == 2)
  {
    cfg.reverbDamping += value;
    cfg.reverbDamping = constrain(cfg.reverbDamping, 0, 1.0);
  }


  // update screen with selected slider and new value
  if (reverbScreenFocusItemChanged || reverbValueChanged)
  {
    Serial.print("reverbScreenFocusItem = "); Serial.println(reverbScreenFocusItem);
    Serial.print("reverbVolume = "); Serial.println(cfg.reverbVolume);
    Serial.print("reverbRoomsize = "); Serial.println(cfg.reverbRoomsize);
    Serial.print("reverbScreenFocusItem = "); Serial.println(cfg.reverbDamping);

    position = (uint8_t)(cfg.reverbVolume * 100.0); // 0 to 100%
    drawSlider(s1x, 0, position, reverbScreenFocusItem == 0);

    position = (uint8_t)(cfg.reverbRoomsize * 100.0);
    drawSlider(s2x, 0, position, reverbScreenFocusItem == 1);

    position = (uint8_t)(cfg.reverbDamping * 100.0);
    drawSlider(s3x, 0, position, reverbScreenFocusItem == 2);

    mixer1.gain(2, cfg.reverbVolume);
    freeverb1.roomsize(cfg.reverbRoomsize);
    freeverb1.damping(cfg.reverbDamping);
  }

  reverbScreenFocusItemChanged = false;
  reverbValueChanged = false;
}
