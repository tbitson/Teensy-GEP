/*
 * utils. h - various support functions
 * 
 * version 1.1.0
 * Dec 2019
 * 
 * 
 * 
 */



#include "logo.c"
#include "patches.h"


// comment out when not debugging
#define DEBUG_PRINT

extern const String VERSION;
extern ILI9341_t3 tft;
extern bool msgFlag;


// prototypes
void splashScreen();
void drawBorder(uint16_t);
void tftMessage(String);
void printValue(String, float);
void printAudioMemUsage();






// display splash Screen
void splashScreen()
{
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.writeRect(80, 20, logo.width, logo.height, (uint16_t*)(logo.pixel_data));

  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(100, 100);
  tft.setFont(Arial_20);
  tft.print("Teensy");

  tft.setCursor(10, 140);
  tft.setFont(Arial_20);
  tft.print("Guitar Effects Processor");

  tft.setCursor(85, 180);
  tft.setFont(Arial_14);
  tft.print(VERSION);
}


void drawBorder(uint16_t borderColor)
{
  tft.drawRect(0, 0, 319, 239, borderColor);
}



// show message on the lcd
void tftMessage(String message)
{
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(80, 60);
  tft.setFont(Arial_16);
  tft.print(message);
  delay(1000);
  tft.fillScreen(ILI9341_BLACK);
  msgFlag = false;
}



// simple helper function that print data to the serial port
void printValue(const char* msg)
{
  #ifdef DEBUG_PRINT
  Serial.println(msg);
  #endif
}



// simple helper function that print data to the serial port
void printValue(const char* msg, float val)
{
  #ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val);
  #endif
}


// simple helper function that print data to the serial port
void printValue(const char* msg, int val1, float val2)
{
  #ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" ");
  Serial.print(val1);
    Serial.print(" = ");
  Serial.println(val2);
  #endif
}




// simple helper function that print data to the serial port
void printArryValue(const char* msg, uint8_t index, float val)
{
  #ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print("[");
  Serial.print(index);
  Serial.print("] = ");
  Serial.println(val);
  #endif
}



void printAudioMemUsage()
{
  #ifdef DEBUG_PRINT
  //Serial.print("CPU Usage     : "); Serial.print(processorUsage());
  //Serial.print("     max: ");       Serial.println(AudioProcessorUsageMax());
  Serial.print("FV Usage      : "); Serial.print(freeverb1.processorUsage());
  Serial.print("     max: ");       Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioProcessor: "); Serial.print(AudioProcessorUsage());
  Serial.print("  max: ");          Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioMem      : "); Serial.print(AudioMemoryUsage());
  Serial.print(" .    max: ");      Serial.println(AudioMemoryUsageMax());
  Serial.println();
  #endif
}



/* 
// debugging aid - call to reboot teensy
#define RESTART_ADDR 0xE000ED0C
#define READ_RESTART() (*(volatile uint32_t *)RESTART_ADDR)
#define WRITE_RESTART(val) ((*(volatile uint32_t *)RESTART_ADDR) = (val))

void reboot_teensy()
{
  WRITE_RESTART(0x5FA0004);
}
*/
