/*
    EqScreen.h

    handles the EQ screen drawing and updates
    the EQ settings in the audio chip

    version 2.0.1  Dec 2019

*/



#include "guiElements.h"

//#define TEST
//#define DEBUG_MODE


// prototypes
void initEqualizer();
void calcParametricEQ();
void convertEqToSlider();
void doEqScreen();
void drawEqScreen();
void convertSliderToEq();
bool checkEncoders(uint8_t);



// constants
#define NUM_ITEMS 5
// EQ band frequecies
const float eqBandFrequencies[] = { 100.0, 250.0, 600.0, 1300.0, 3000.0 };


// global vars
int16_t selectedItem = 0;
int16_t lastSelectedItem = 0;
bool selectedItemChanged = false;
bool itemValueChanged = false;
float sliderPos[NUM_ITEMS];

#ifdef TEST
uint8_t value = 50;
int8_t dir = 1;
#endif






void initEqualizer()
{
  // set up the eq bands and ranges
  calcParametricEQ();
  initialScreenDrawn = false;
}



void calcParametricEQ()
{
  // calc and update the EQ parameters for the audio chip
  for (uint8_t i = 0; i < NUM_ITEMS; i++)
  {
    calcBiquad(FILTER_PARAEQ, eqBandFrequencies[i], cfg.eqBandVals[i], 1, 524288, 44100, updateFilter);
    audioShield.eqFilter(1, updateFilter);
  }
}




// main EQ screen loop
void doEqScreen()
{
  selectedItemChanged = false;
  itemValueChanged = false;

  // set the sliders values to the current stored eq settings
  if (!initialScreenDrawn)
    convertEqToSlider();

  // read encoders and check for changes
  checkEncoders(NUM_ITEMS);

  // draw the screen
  if (selectedItemChanged || itemValueChanged || !initialScreenDrawn)
  {
    convertSliderToEq();
    
    #ifdef TEST
    for (int loops = 0; loops < 500; loops++)
    {
      sliderPos[0] = value;
      drawEqScreen();
      delay(10);
      value += dir;
      if (value > 100)
      {
        dir = -1;
        Serial.println("100%");
        delay(1000);
      }
      if (value == 0)
      {
        dir = 1;
        Serial.println("0%");
        delay(1000);
      }
    }
    #endif

    drawEqScreen();
    convertSliderToEq();
    calcParametricEQ();

    lastParamEncVal = paramEncVal;
    lastValEncVal = valEncVal;
  }
}



void convertEqToSlider() // updateSliderValues()
{
  // convert eq settings -1.0 to +1.0 to slider level of 0 to 100%
  for (uint8_t i = 0; i < NUM_ITEMS; i++)
  {
    sliderPos[i] = (cfg.eqBandVals[i] + 1.0) * 50;
    //printArryValue("1) sliderPos", i, sliderPos[i]);
  }
}




void convertSliderToEq() //  updateEqValues()
{
  // convert slider position to EQ values
  // sliderPos[i] = 0 to 100%, convert to +/- 1.0

  for (uint8_t i = 0; i < NUM_ITEMS; i++)
  {
    cfg.eqBandVals[i] = sliderPos[i] / 50.0 - 1.0;

    //printArryValue("sliderPos", i, sliderPos[i]);
    //printArryValue("cfg.eqBandVals", i, cfg.eqBandVals[i]);
  }
}




void drawEqScreen()
{
  // slider spacing
  uint16_t xSep = 61;

  // slider x positions
  uint16_t sx[NUM_ITEMS];
  for (uint8_t i = 0; i < NUM_ITEMS; i++)
    sx[i] = i * xSep + 21;

  // slider y positions
  uint16_t sy = 0;

  if (!initialScreenDrawn)
  {
    Serial.println("Initializing EQ Screen");
    selectedItem = 0;

    // reset encoders
    paramEncoder.write(0);
    valueEncoder.write(0);
    lastParamEncVal = 0;
    lastValEncVal = 0;

    // draw screen text
    tft.fillScreen(GUI_FILL_COLOR);
    tft.setTextColor(GUI_ITEM_COLOR);
    tft.setFont(Arial_14);
    tft.setCursor(20, 200);  // 0, 9, 17, 24, 32
    tft.print("100      250     600    1300    3000");
    tft.setCursor(90, 220);
    tft.setTextColor(GUI_TEXT_COLOR);
    tft.print("Parametric EQ");
  }


  // first time we need to draw all items
  if (!initialScreenDrawn || selectedItemChanged)
  {
    
    for (uint8_t i = 0; i < NUM_ITEMS; i++)
    {
      if (i == selectedItem)
        drawSlider(sx[i], sy, sliderPos[i], true);
      else
        drawSlider(sx[i], sy, sliderPos[i], false);
    }
  }
  // otherwise only draw selected item
  else
    drawSlider(sx[selectedItem], sy, sliderPos[selectedItem], true);

  initialScreenDrawn = true;
}







bool checkEncoders(uint8_t numItems)
{
  // checks both param & value encoders for changes
  // read the param encoder first, which selects the
  // gui item. If changed, exits with the new
  // "selected item". If no changes, the value encoder
  // is read. Changes to value encode increase or decrease
  // the value of the "selected item"

  // store the current value as baseline and read Parameter Encoder
  lastParamEncVal = paramEncVal;
  paramEncVal = readParamEncoder();

  if (paramEncVal != lastParamEncVal)
  {
    printValue("paramEncVal", paramEncVal);
    printValue("lastParamEncVal", lastParamEncVal);

    // save the current selected item
    lastSelectedItem = selectedItem;

    // and then move to next or previous item
    if (paramEncVal > lastParamEncVal)
      selectedItem++;
    else if (paramEncVal < lastParamEncVal)
      selectedItem--;

    // make sure we stay in bounds
    selectedItem = constrain(selectedItem, 0, numItems - 1);
    printValue("selectedItem", selectedItem);
    
    selectedItemChanged = true;
    return true;
  }

  else

  {
    // if no param encoder changes, then read Value Encoder
    lastValEncVal = valEncVal;
    valEncVal = readValueEncoder();

    if (valEncVal != lastValEncVal)
    {
      printValue("valEncVal", valEncVal);
      printValue("lastValEncVal", lastValEncVal);

      // increase or decrease the slider's new position (need to re-draw later)
      if (valEncVal > lastValEncVal)
        sliderPos[selectedItem] += 8;

      else if (valEncVal < lastValEncVal)
        sliderPos[selectedItem] -= 8;

      // keep it in the slider's range
      sliderPos[selectedItem] = constrain(sliderPos[selectedItem], 0, 100.0);
      printValue("sliderPos[selectedItem]", sliderPos[selectedItem]);
      itemValueChanged = true;
    }
    return true;
  }

  // nothing changed
  return false;
}
