/*******************************************************************************
   Global settings variables and functions to
   save and load to non-volatile memory (EEPROM)

   version 0.0 - will replace settings.h when done


*******************************************************************************/

#ifndef CONFIG_H
#define CONFIG_H


// prototypes
bool saveConfig();
bool loadConfig();
void printConfig();
void clearEEPROM();
void showEEPROM();



// if the first byte of stored data matches this, it
// is assumed valid data for this version
#define EEPROM_VERSION 22
#define eeAddress      0


// equalizer bands
enum eqBands {BASS, MID_BASS, MIDRANGE, MID_TREBLE, TREBLE};


// *** default settings NOT avaiable in GUI  nor stored in eeprom ***

#define HEADPHONE_OUTPUT_LEVEL 0.7
#define LINEOUT_AUDIO_LEVEL    8

// wah-wah settings
const int WAH_WAH_CENTER_FREQ = 500;
const int WAH_WAH_GAIN        = 4;
const int WAH_WAH_OCTAVES     = 2;  // +/- 2 octaves

// flanger
const int FLANGE_DELAY_LENGTH = 8 * AUDIO_BLOCK_SAMPLES;  // x 2 to 12
const int MAX_FLANGER_DEPTH   = FLANGE_DELAY_LENGTH / 4;  // * 1 to 3
const int SIDX                = FLANGE_DELAY_LENGTH / 4;  // / 4 to 8

// more of a chorus-like effect for flanger
//const int FLANGE_DELAY_LENGTH = 12 * AUDIO_BLOCK_SAMPLES;
//const int MAX_FLANGER_DEPTH   = FLANGE_DELAY_LENGTH / 8;
//const int SIDX                = 3 * FLANGE_DELAY_LENGTH / 4;

short delayline[FLANGE_DELAY_LENGTH];



struct Config
{
  byte    vers;

  float   eqBandVals[5];
  int     updateFilter[5];

  uint8_t compressorGain;
  uint8_t compressorResponse;
  uint8_t compressorHardLimit;
  float   compressorThreshold;
  float   compressorAttack;
  float   compressorDecay;

  float   tremoloSpeed;
  float   tremoloDepth;

  float   flangerSpeed;
  int     flangerDepth;

  float   reverbVolume;
  float   reverbRoomsize;
  float   reverbDamping;

  int     inputValueAdj;

  uint8_t lastMenu;

  // add:
  // current screen
  // effects switches state
} cfg;




void initConfig()
{
  // config version
  cfg.vers                    = EEPROM_VERSION;

  // equalizer - set for flat response
  cfg.eqBandVals[BASS]        = 0.0;
  cfg.eqBandVals[MID_BASS]    = 0.0;
  cfg.eqBandVals[MIDRANGE]    = 0.0;
  cfg.eqBandVals[MID_TREBLE]  = 0.0;
  cfg.eqBandVals[TREBLE]      = 0.0;

  // compressor
  cfg.compressorGain      = 1;      // 0,1,2 = 0, 6, 12db
  cfg.compressorResponse  = 3;      // integration time 0,1,2,3 = 0,25,50,100ms
  cfg.compressorHardLimit = 0;      // 0 or 1, 0 = soft knee, not in gui
  cfg.compressorThreshold = 18;     // 0 to -96dbBFS
  cfg.compressorAttack    = 50;     // db per sec
  cfg.compressorDecay     = 100;    // db per sec

  // tremolo
  cfg.tremoloSpeed    = 3.0;
  cfg.tremoloDepth    = 0.2;

  // reverb
  cfg.reverbVolume    = 0.7;
  cfg.reverbRoomsize  = 0.5;
  cfg.reverbDamping   = 0.3;

  // flanger
  cfg.flangerDepth   = FLANGE_DELAY_LENGTH / 8;
  cfg.flangerSpeed    = 0.3;   // 3.3 second sweep

  // input level
  cfg.inputValueAdj = 10;
  cfg.lastMenu = 0;
}



bool saveConfig()
{
  cfg.vers = EEPROM_VERSION;
  
  EEPROM.put(eeAddress, cfg);
  Serial.print("Saved "); Serial.print(sizeof(cfg)); Serial.println(" bytes");
  
  printConfig();
  return true;
}



bool loadConfig()
{
  byte version;

  EEPROM.get(eeAddress, version);
  Serial.print("eeprom vers read = "); Serial.println(version);
  Serial.print("eeprom vers running = "); Serial.println(EEPROM_VERSION);

  if (version == EEPROM_VERSION)
  {
    EEPROM.get(eeAddress, cfg);
    Serial.println("Config loaded");
    Serial.print("loaded "); Serial.print(sizeof(cfg)); Serial.println(" bytes");
    printConfig();
    return true;
  }
  else
  {
    Serial.println("Config NOT loaded, using defaults");
    showEEPROM();
    clearEEPROM();
  }
    
  return false;
}



void printConfig()
{
  Serial.println(F("Current Config:"));
  Serial.print(F("vers = "));                Serial.println(cfg.vers);
  Serial.print(F("bass = "));                Serial.println(cfg.eqBandVals[BASS]);
  Serial.print(F("mid_bass = "));            Serial.println(cfg.eqBandVals[MID_BASS]);
  Serial.print(F("midrange = "));            Serial.println(cfg.eqBandVals[MIDRANGE]);
  Serial.print(F("mid_treble = "));          Serial.println(cfg.eqBandVals[MID_TREBLE]);
  Serial.print(F("treble = "));              Serial.println(cfg.eqBandVals[TREBLE]);
  Serial.print(F("compressorGain = "));      Serial.println(cfg.compressorGain);
  Serial.print(F("compressorResponse = "));  Serial.println(cfg.compressorResponse);
  Serial.print(F("compressorThreshold = ")); Serial.println(cfg.compressorThreshold);
  Serial.print(F("compressorAttack = "));    Serial.println(cfg.compressorAttack);
  Serial.print(F("compressorDecay = "));     Serial.println(cfg.compressorDecay);
  Serial.print(F("tremoloSpeed = "));        Serial.println(cfg.tremoloSpeed);
  Serial.print(F("tremoloDepth = "));        Serial.println(cfg.tremoloDepth);
  Serial.print(F("flangerSpeed = "));        Serial.println(cfg.flangerSpeed);
  Serial.print(F("flangerDepth = "));        Serial.println(cfg.flangerDepth);
  Serial.print(F("reverbVolume = "));        Serial.println(cfg.reverbVolume);
  Serial.print(F("reverbRoomsize = "));      Serial.println(cfg.reverbRoomsize);
  Serial.print(F("reverbDamping = "));       Serial.println(cfg.reverbDamping);
  Serial.print(F("inputValueAdj = "));       Serial.println(cfg.inputValueAdj);
  Serial.println();
}




// clear eeprom contents (dev use only so far)
void clearEEPROM()
{
  Serial.println("Clearing EEPROM...");

  for (int i = 0 ; i < EEPROM.length() ; i++)
    EEPROM.write(i, 0);

  Serial.println("done");
}


// show eeprom contents (dev use only so far)
void showEEPROM()
{
  byte b;

  Serial.println("EEPROM contents:");

  for (int i = 0 ; i < EEPROM.length() ; i++)
  {
    EEPROM.get(i, b);
    
    Serial.print("Addr 0x");
    Serial.print(i, HEX);
    Serial.print(" = ");
    Serial.println(b);
  }
  
  Serial.println();
}

#endif
