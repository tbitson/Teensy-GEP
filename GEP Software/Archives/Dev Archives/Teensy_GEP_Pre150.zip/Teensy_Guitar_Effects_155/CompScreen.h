/*
    Compressor. h - code for the Auto Volume Control (AVC)
    also called the Compressor

    version 2.0B1
    Dec 2019



*/


#include "guiElements.h"


// prototypes
void updateCompressorSettings();
void disableCompressor();
void enableCompressor();
void updateExpanderGain();
void updateExpanderResponse();
void updateCompressorThreshold();
void updateCompressorAttack();
void updateCompressorDecay();



// external hardware globals
//extern ILI9341_t3 tft;
//extern XPT2046_Touchscreen ts;
extern Encoder valueEncoder;
extern Encoder paramEncoder;
//extern Bounce compressorSwitch;
//extern Bounce tunerSwitch;
//extern Bounce saveSwitch;




// global vars in this file
boolean compressorActive = false;
boolean compScreenInitialized;





void initCompressor()
{
  disableCompressor();
  updateCompressorSettings();
  compScreenInitialized = false;
}



void disableCompressor()
{
  compressorActive = false;
  audioShield.autoVolumeDisable();
  Serial.println("Compressor OFF");
}



void enableCompressor()
{
  compressorActive = true;
  audioShield.autoVolumeEnable();
  Serial.println("Compressor ON");
}




// primary compressor settings function
void updateCompressorSettings()
{
  // configure the compressor with current settings
  // gain: 0 = 0dB, 1 = 6dB, 2 = 12dB
  // response (integration time): 0 = 0ms, 1 = 25ms, 2 = 50 ms, 3 = 100 ms (values > 3 permissible)
  // hardLimit: 0 = use "soft knee', 1 = hard limit (don't allow values > threshold)
  // threshold: 0 to -96 dBFS
  // attack: controls decease in gain in dB per second
  // decay: how fast gain is restored in dB per second
  audioShield.autoVolumeControl(cfg.compressorGain, cfg.compressorResponse, cfg.compressorHardLimit,
                                cfg.compressorThreshold, cfg.compressorAttack, cfg.compressorDecay);
}



void drawInitialCompressorScreen()
{
  int pos;
  paramEncoder.write(0);
  compScreenFocusItem = 0;
  lastParamEncVal = 0;
  valueEncoder.write(0);
  lastValEncVal = 0;
  lastCompScreenFocusItem = -1;

  tft.fillScreen(GUI_FILL_COLOR);
  tft.setFont(Arial_14);
  tft.setTextColor(ILI9341_CYAN);
  tft.setCursor(0, 200);
  tft.print("Gain");
  tft.setTextColor(GUI_ITEM_COLOR);
  tft.print("    Resp      Thresh Attack Decay");
  tft.setCursor(0, 220);
  tft.setTextColor(ILI9341_WHITE);
  tft.print("  Expander             Compressor");
  tft.drawFastVLine(130, 0, 239, ILI9341_CYAN);

  switch (cfg.compressorGain)
  {
    case 0:
      tft.fillCircle(20, 60, 10, ILI9341_RED);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(20, 60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_RED);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(20, 60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_RED);
  }

  tft.setCursor(0, 30);
  tft.print("0 dB");
  tft.setCursor(0, 90);
  tft.print("6 dB");
  tft.setCursor(0, 150);
  tft.print("12 dB");

  switch (cfg.compressorResponse)
  {
    case 0:
      tft.fillCircle(80, 40, 10, ILI9341_RED);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_RED);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_RED);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 3:
      tft.fillCircle(80, 40, 10, ILI9341_WHITE);
      tft.fillCircle(80, 90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_RED);
  }

  tft.setCursor(65, 10);
  tft.print("0 ms");
  tft.setCursor(65, 60);
  tft.print("25 ms");
  tft.setCursor(65, 110);
  tft.print("50 ms");
  tft.setCursor(65, 160);
  tft.print("100 ms");

  // Draw 3 sliders
  pos = 182 - (int)(cfg.compressorThreshold * 0.002777);  // scale 0->65535 into  182 ->0
  tft.fillRoundRect(145, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(145, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(145, pos + 3, 29, 4, GUI_FILL_COLOR);

  pos = 182 - ((int)(cfg.compressorAttack * 0.1777));   // scale 0->1024 into 182 ->0
  tft.fillRoundRect(203, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(203, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(203, pos + 3, 29, 4, GUI_FILL_COLOR);

  pos = 182 - ((int)(cfg.compressorDecay * 0.0888));   // scale 0->2048 into 182 ->0
  tft.fillRoundRect(261, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(261, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(261, pos + 3, 29, 4, GUI_FILL_COLOR);

  compScreenFocusItemChanged = false;
  compressorValueChanged = false;
}



void updateCompressorScreen()
{
  // First handle parameter encoder changes
  paramEncVal = paramEncoder.read() >> 2;
  if (paramEncVal > lastParamEncVal)
  {
    lastCompScreenFocusItem = compScreenFocusItem;
    compScreenFocusItem++;
    compScreenFocusItem = constrain(compScreenFocusItem, 0, 4);
    compScreenFocusItemChanged = true;
    lastParamEncVal = paramEncVal;
  }

  if (paramEncVal < lastParamEncVal)
  {
    lastCompScreenFocusItem = compScreenFocusItem;
    compScreenFocusItem--;
    compScreenFocusItem = constrain(compScreenFocusItem, 0, 4);
    compScreenFocusItemChanged = true;
    lastParamEncVal = paramEncVal;
  }

  if (compScreenFocusItemChanged == true)
  {
    switch (compScreenFocusItem)
    {
      case 0:
        tft.setTextColor(ILI9341_CYAN);
        tft.setCursor(0, 200);
        tft.print("Gain");
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("    Resp      Thresh Attack Decay");
        break;

      case 1:
        tft.setCursor(0, 200);
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Gain");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("    Resp");
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("      Thresh Attack Decay");
        break;

      case 2:
        tft.setCursor(0, 200);
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Gain    Resp");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("      Thresh ");
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Attack Decay");
        break;

      case 3:
        tft.setCursor(0, 200);
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Gain    Resp      Thresh ");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("Attack ");
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Decay");
        break;

      case 4:
        tft.setCursor(0, 200);
        tft.setTextColor(GUI_ITEM_COLOR);
        tft.print("Gain    Resp      Thresh Attack ");
        tft.setTextColor(ILI9341_CYAN);
        tft.print("Decay");
        break;
    }
    compScreenFocusItemChanged = false;
  }

  // Next handle Value encoder changes
  valEncVal = valueEncoder.read() >> 2;
  if (valEncVal > lastValEncVal)
  {
    CompressorAdjustValue = 1;
    compressorValueChanged = true;
    lastValEncVal = valEncVal;
  }

  if (valEncVal < lastValEncVal)
  {
    CompressorAdjustValue = -1;
    compressorValueChanged = true;
    lastValEncVal = valEncVal;
  }

  if (compressorValueChanged == true)
  {
    switch (compScreenFocusItem)
    {
      case  0: updateExpanderGain(); break;
      case  1: updateExpanderResponse(); break;
      case  2: updateCompressorThreshold(); break;
      case  3: updateCompressorAttack(); break;
      case  4: updateCompressorDecay();
    }
    compressorValueChanged = false;
  }
}



void updateExpanderGain()
{
  cfg.compressorGain += CompressorAdjustValue;
  cfg.compressorGain = constrain(cfg.compressorGain, 0, 2);
  switch (cfg.compressorGain) {
    case 0:
      tft.fillCircle(20,  60, 10, ILI9341_RED);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(20,  60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_RED);
      tft.fillCircle(20, 180, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(20,  60, 10, ILI9341_WHITE);
      tft.fillCircle(20, 120, 10, ILI9341_WHITE);
      tft.fillCircle(20, 180, 10, ILI9341_RED);
  }

  updateCompressorSettings();

#ifdef DEBUG_MODE
  Serial.print(cfg.compressorGain);
#endif
}



void updateExpanderResponse()
{
  cfg.compressorResponse += CompressorAdjustValue;
  cfg.compressorResponse = constrain(cfg.compressorResponse, 0, 3);

  switch (cfg.compressorResponse)
  {
    case 0:
      tft.fillCircle(80,  40, 10, ILI9341_RED);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 1:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_RED);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 2:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_RED);
      tft.fillCircle(80, 190, 10, ILI9341_WHITE);
      break;

    case 3:
      tft.fillCircle(80,  40, 10, ILI9341_WHITE);
      tft.fillCircle(80,  90, 10, ILI9341_WHITE);
      tft.fillCircle(80, 140, 10, ILI9341_WHITE);
      tft.fillCircle(80, 190, 10, ILI9341_RED);
  }

  updateCompressorSettings();

#ifdef DEBUG_MODE
  Serial.print(cfg.compressorResponse);
#endif
}



void updateCompressorThreshold()
{
  int pos;
  cfg.compressorThreshold += CompressorAdjustValue;
  cfg.compressorThreshold = constrain(cfg.compressorThreshold, 0, 65535);

  pos = 182 - (int) ((float) cfg.compressorThreshold * 0.002777); // scale 0->65535 into  182 ->0
  tft.fillRoundRect(145, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(145, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(145, pos + 3, 29, 4, GUI_FILL_COLOR);

  updateCompressorSettings();

#ifdef DEBUG_MODE
  Serial.println("Compressor Threshold");
#endif
}



void updateCompressorAttack()
{
  int pos;
  cfg.compressorAttack += CompressorAdjustValue * 16;
  cfg.compressorAttack = constrain(cfg.compressorAttack, 0, 1024);   // use only 1/4 of 12-bit range of SGTL5000 (about 800 dB/sec)
  pos = 182 - ((int)(cfg.compressorAttack * 0.1777));  // scale 0->1024 into 182 ->0
  tft.fillRoundRect(203, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(203, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(203, pos + 3, 29, 4, GUI_FILL_COLOR);

  updateCompressorSettings();

#ifdef DEBUG_MODE
  Serial.println(cfg.compressorAttack);
#endif
}


void updateCompressorDecay()
{
  int pos;
  cfg.compressorDecay += CompressorAdjustValue * 32;
  cfg.compressorDecay = constrain(cfg.compressorDecay, 0, 2048);   // use only 1/2 of 12-bit range of SGTL5000 (about 100 dB/sec)

  pos = 182 - ((int)(cfg.compressorDecay * 0.0888));   // scale 0->2048 into 182 ->0
  tft.fillRoundRect(261, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(261, pos, 29, 10, 8, GUI_ITEM_COLOR);
  tft.fillRect(261, pos + 3, 29, 4, GUI_FILL_COLOR);

  updateCompressorSettings();

#ifdef DEBUG_MODE
  Serial.println(cfg.compressorDecay);
#endif
}
