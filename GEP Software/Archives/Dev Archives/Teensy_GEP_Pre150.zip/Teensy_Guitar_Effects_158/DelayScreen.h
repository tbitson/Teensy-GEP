/*
    Delay. h - code to implement the multi-channel delay


    version 0
    Dec 2019

    just a placeholder for now

    Notes:
    add 4 delays
    add 1 mixer
    have 4 delay & 4 volume sliders
    enable button

*/





#include "guiElements.h"


// prototypes
void initDelay();
void disableDelay();
void enableDelay();




// global vars
bool delayActive;



void initDelay()
{
  disableDelay();
    Serial.println("Delay Initialized");
}


void enableDelay()
{
  delayActive = true;
}



void disableDelay()
{
  delayActive = false;
}
