/*
    InputLevel. h - code for the input level adjustment

    version 2.0B1
    Dec 2019



*/


#include "guiElements.h"



// prototypes
void initInputLevel();
void drawInitialInputTrimScreen();
void updateInputTrimScreen();



// global vars
float maxEQ = 0;




void initInputLevel()
{

}






void drawInitialInputTrimScreen()
{
  int pos;
  tft.fillScreen(GUI_FILL_COLOR);
  tft.setTextColor(GUI_ITEM_COLOR);
  tft.setFont(Arial_14);
  tft.setCursor(40, 200);
  tft.print("Input Level Adjust");

  // Draw 1 Slider
  cfg.inputValueAdj = constrain(cfg.inputValueAdj, 0, 15);
  pos = 182 - cfg.inputValueAdj * 12; //scale 0 -> 15 into 182 -> 0
  tft.fillRoundRect(29, 0, 29, 192, 8, GUI_SHAPE_COLOR);
  tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ITEM_COLOR);
  tft.fillRect(29, pos + 3, 29, 4, GUI_FILL_COLOR);

  // draw outline around Vu Meter
  tft.drawRect(148, 0, 35, 190, GUI_TEXT_COLOR);
  Input_TrimChanged = false;
  initialScreenDrawn = true;

  // determine max EQ band db: use for safe input level determination during input level metering
  maxEQ = 0;

  if (cfg.eqBandVals[BASS] > maxEQ)
    maxEQ = cfg.eqBandVals[BASS];

  if (cfg.eqBandVals[MID_BASS] > maxEQ)
    maxEQ = cfg.eqBandVals[MID_BASS];

  if (cfg.eqBandVals[MIDRANGE] > maxEQ)
    maxEQ = cfg.eqBandVals[MIDRANGE];

  if (cfg.eqBandVals[MID_TREBLE] > maxEQ)
    maxEQ = cfg.eqBandVals[MID_TREBLE];

  if (cfg.eqBandVals[TREBLE] > maxEQ)
    maxEQ = cfg.eqBandVals[TREBLE];
}


void updateInputTrimScreen()
{
  int pos;

  //  handle Value Encoder
  valEncVal = valueEncoder.read() >> 2;
  if (valEncVal > lastValEncVal)
  {
    cfg.inputValueAdj += 1;
    cfg.inputValueAdj = constrain(cfg.inputValueAdj, 0, 15);

    pos = 182 - cfg.inputValueAdj * 12;  //scale 0 -> 15 into 182 -> 0
    tft.fillRoundRect(29, 0, 29, 192, 8, GUI_SHAPE_COLOR);
    tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ITEM_COLOR);
    tft.fillRect(29, pos + 3, 29, 4, GUI_FILL_COLOR);
    audioShield.lineInLevel(cfg.inputValueAdj);
    Input_TrimChanged = true;
    lastValEncVal = valEncVal;
  }

  if (valEncVal < lastValEncVal)
  {
    cfg.inputValueAdj -= 1;
    cfg.inputValueAdj = constrain(cfg.inputValueAdj, 0, 15);

    pos = 182 - cfg.inputValueAdj * 12;  //scale 0 -> 15 into 182 -> 0
    tft.fillRoundRect(29, 0, 29, 192, 8, GUI_SHAPE_COLOR);
    tft.fillRoundRect(29, pos, 29, 10, 8, GUI_FOCUS_ITEM_COLOR);
    tft.fillRect(29, pos + 3, 29, 4, GUI_FILL_COLOR);

    audioShield.lineInLevel(cfg.inputValueAdj);
    Input_TrimChanged = true;
    lastValEncVal = valEncVal;
  }

  if (peak1.available())
  {
    int Vu_Color;
    int Vu_Height;
    float Vu;

    Vu = peak1.readPeakToPeak();
    Vu = Vu  * exp10(maxEQ / 20.0);    // ADJUST FOR MAX EQ SETTING AS A SAFETY FACTOR IN PREVENTING OVERLOAD
    if (Vu > 0)
    {
      Vu_Height = (int)((1.0 + log(Vu)) * 90.0); // convert to a VU-style logarithmic readout
      Vu_Height = constrain(Vu_Height, 0, 182);

      if (Vu_Height < 90)
        Vu_Color = ILI9341_GREEN;
      if (Vu_Height > 90)
        Vu_Color = ILI9341_YELLOW;
      if (Vu_Height > 140)
        Vu_Color = ILI9341_RED;

      tft.fillRoundRect(150, 2, 29, 184 - Vu_Height, 4, GUI_FILL_COLOR);
      tft.fillRoundRect(150, 184 - Vu_Height, 29, Vu_Height, 4, Vu_Color);
    //tft.fillRectVGradient(150, 184 - vuHeight, 29, vuHeight, ILI9341_RED, ILI9341_GREEN);


      delay(50);
    }
  }
}
