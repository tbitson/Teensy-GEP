/*   utils. h - various support functions
 * 
 * version 1.1.0   Dec 2019
 * 
 * Various utility and helper functions 
 * 
 * 
 * 
 * 
 * 
 */



// prototypes
void printValue(const char* msg);
void printValue(String, int);
void printValue(String, long);
void printValue(String, float);
void printValue(const char*, int, float);
void printArryValue(const char* , uint8_t, float);
void printAudioMemUsage();






// simple helper functions that print data to the serial port
// undefining DEBUG_PRINT disables all output
void printValue(const char* msg)
{
#ifdef DEBUG_PRINT
  Serial.print("msg = ");
  Serial.println(msg);
#endif
}


void printValue(const char* msg, int val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val);
#endif
}


void printValue(const char* msg, long val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val);
#endif
}


void printValue(const char* msg, float val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val, 1);
#endif
}


void printValue(const char* msg, int val1, float val2)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" ");
  Serial.print(val1);
  Serial.print(" = ");
  Serial.println(val2);
#endif
}




void printArryValue(const char* msg, uint8_t index, float val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print("[");
  Serial.print(index);
  Serial.print("] = ");
  Serial.println(val);
#endif
}



void printAudioMemUsage()
{
#ifdef DEBUG_PRINT
  //Serial.print("CPU Usage     : "); Serial.print(processorUsage());
  //Serial.print("     max: ");       Serial.println(AudioProcessorUsageMax());
  Serial.print("FV Usage      : "); Serial.print(freeverb1.processorUsage());
  Serial.print("     max: ");       Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioProcessor: "); Serial.print(AudioProcessorUsage());
  Serial.print("  max: ");          Serial.println(AudioProcessorUsageMax());
  Serial.print("AudioMem      : "); Serial.print(AudioMemoryUsage());
  Serial.print(" .    max: ");      Serial.println(AudioMemoryUsageMax());
  Serial.println();
#endif
}



/*
  // debugging aid - call to reboot teensy
  #define RESTART_ADDR 0xE000ED0C
  #define READ_RESTART() (*(volatile uint32_t *)RESTART_ADDR)
  #define WRITE_RESTART(val) ((*(volatile uint32_t *)RESTART_ADDR) = (val))

  void reboot_teensy()
  {
  WRITE_RESTART(0x5FA0004);
  }
*/
