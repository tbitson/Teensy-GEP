/*******************************************************************************
   Guitar tuner code, frequencies, and note arrays

    vers 1.0

*******************************************************************************/



// tuner values
float Guitar_Note[40];
String NoteName[40];

extern Bounce tunerSwitch;
extern ILI9341_t3 tft;

void Assign_Guitar_Note_Array();


void guitarTuner()
{
  float abs_delta, delta, note,  minimum_Delta, minimum_abs_Delta, higher_Note, lower_Note, cents;
  String note_String, last_Note_String;
  uint16_t cents_Graphic;
  uint16_t k;

  Assign_Guitar_Note_Array();

  higher_Note = 0;
  lower_Note = 0;
  minimum_Delta = 0;

#ifdef DEBUG_MODE
  Serial.println("Guitar Tuna");
#endif

  // Disable all but 1st of the External delays (to cut back on CPU useage)
  delayExt1.disable(1);
  delayExt1.disable(2);
  delayExt1.disable(3);
  delayExt1.disable(4);

  // Disable the Flanger processingto cut back on CPU useage)
  flange1.voices(0, 0, 0);

  tft.fillScreen(ILI9341_BLACK);
  tft.setFont(Arial_32);
  tft.setCursor(30, 0);
  tft.print("Guitar Tuna");
  tft.setFont(Arial_60);

  k = 50;
  tft.fillRoundRect(0,   k, 64, 50, 0, ILI9341_RED);
  tft.fillRoundRect(64,  k, 80, 50, 0, ILI9341_YELLOW);
  tft.fillRoundRect(144, k, 32, 50, 0, ILI9341_GREEN);
  tft.fillRoundRect(176, k, 80, 50, 0, ILI9341_YELLOW);
  tft.fillRoundRect(256, k, 63, 50, 0, ILI9341_RED);

  tft.setTextColor(ILI9341_WHITE);

  // may halt until a freq is detected
  notefreq1.begin(0.15);

  delay(1000);

  bool tuningMode = true;
  while (tuningMode)
  {
    if (notefreq1.available())
    {
      minimum_abs_Delta = 9999;
      note = notefreq1.read();

#ifdef DEBUG_MODE
      Serial.print("freq = ");
      Serial.println(note);
#endif

      for (int i = 0; i < 35; i++)
      {
        delta = note - Guitar_Note[i];
        abs_delta = abs(delta);
        if (abs_delta < minimum_abs_Delta)
        {
          minimum_abs_Delta = abs_delta;
          minimum_Delta = delta;
          note_String = NoteName[i];
          if (delta > 0)
          {
            higher_Note = Guitar_Note[i + 1];
            lower_Note = Guitar_Note[i];
          }

          else
          {
            higher_Note = Guitar_Note[i];
            lower_Note = Guitar_Note[i - 1];
          }
        }
      }

      if (minimum_Delta > 0)
        cents = (int)(100 * (note - lower_Note) / (higher_Note - lower_Note));
      else
        cents = (int)(100 * ( note - higher_Note) / (higher_Note - lower_Note));

      // transpose +-50 cents to 0-320 X co-ordinates
      cents_Graphic = (uint16_t)((50.0 + cents) * 3.2);
      cents_Graphic = constrain(cents_Graphic, 4, 315);


      // draw background bar graph
      tft.fillRoundRect(  0, k, 64, 50, 0, ILI9341_RED);
      tft.fillRoundRect( 64, k, 80, 50, 0, ILI9341_YELLOW);
      tft.fillRoundRect(144, k, 32, 50, 0, ILI9341_GREEN);
      tft.fillRoundRect(176, k, 80, 50, 0, ILI9341_YELLOW);
      tft.fillRoundRect(256, k, 63, 50, 0, ILI9341_RED);

      // highlight the tuning in black
      tft.fillRoundRect(cents_Graphic - 4, k, 8, 50, 0, ILI9341_BLACK);

      // display the note and octave in large font
      if (note_String != last_Note_String)
      {
        tft.fillRect(99, 149, 160, 80, ILI9341_BLACK);
        tft.setCursor(100, 150);
        tft.print(note_String);
        last_Note_String = note_String;
      }

      delay(150);   // display around 5 readings per sec
    }

    // if tuner switch is pressed again, exit
    tunerSwitch.update();
    if (tunerSwitch.fallingEdge())
    {
#ifdef DEBUG_MODE
      Serial.println("Exiting Tuner");
#endif
      tuningMode = false;
    }
  }

  // shut off notefreq1 processing
  notefreq1.begin(-1.0);

  // re-enable the reverb delays
  delayExt1.delay(1, 300);
  delayExt1.delay(2, 50);
  delayExt1.delay(3, 650);
  delayExt1.delay(4, 850);




}



void Assign_Guitar_Note_Array()
{
  Guitar_Note[1] = 61.714;
  Guitar_Note[2] = 65.385;
  Guitar_Note[3] = 69.268;
  Guitar_Note[4] = 73.425;
  Guitar_Note[5] = 82.410;
  Guitar_Note[6] = 87.273;
  Guitar_Note[7] = 92.500;
  Guitar_Note[8] = 98.000;
  Guitar_Note[9] = 103.784;
  Guitar_Note[10] = 110.000;
  Guitar_Note[11] = 116.522;
  Guitar_Note[12] = 123.249;
  Guitar_Note[13] = 130.769;
  Guitar_Note[14] = 138.537;
  Guitar_Note[15] = 146.830;
  Guitar_Note[16] = 155.556;
  Guitar_Note[17] = 164.800;
  Guitar_Note[18] = 174.545;
  Guitar_Note[19] = 185.000;
  Guitar_Note[20] = 196.000;
  Guitar_Note[21] = 207.568;
  Guitar_Note[22] = 220.000;
  Guitar_Note[23] = 233.043;
  Guitar_Note[24] = 246.940;
  Guitar_Note[25] = 261.538;
  Guitar_Note[26] = 277.073;
  Guitar_Note[27] = 293.699;
  Guitar_Note[28] = 311.111;
  Guitar_Note[29] = 329.630;
  Guitar_Note[30] = 349.091;
  Guitar_Note[31] = 370.000;
  Guitar_Note[32] = 392.000;
  Guitar_Note[33] = 415.135;
  Guitar_Note[34] = 440.000;
  Guitar_Note[35] = 466.087;


  NoteName[1] = "C2 ";
  NoteName[2] = "C#2";
  NoteName[3] = "D2 ";
  NoteName[4] = "D#2";
  NoteName[5] = "E2 ";
  NoteName[6] = "F2 ";
  NoteName[7] = "F#2";
  NoteName[8] = "G2 ";
  NoteName[9] = "G#2";
  NoteName[10] = "A2 ";
  NoteName[11] = "A#2";
  NoteName[12] = "B2 ";
  NoteName[13] = "C3 ";
  NoteName[14] = "C#3";
  NoteName[15] = "D3 ";
  NoteName[16] = "D#3";
  NoteName[17] = "E3 ";
  NoteName[18] = "F3 ";
  NoteName[19] = "F#3";
  NoteName[20] = "G3 ";
  NoteName[21] = "G#3";
  NoteName[22] = "A3 ";
  NoteName[23] = "A#3";
  NoteName[24] = "B3 ";
  NoteName[25] = "C4 ";
  NoteName[26] = "C#4";
  NoteName[27] = "D4 ";
  NoteName[28] = "D#4";
  NoteName[29] = "E4 ";
  NoteName[30] = "F4 ";
  NoteName[31] = "F#4";
  NoteName[32] = "G4 ";
  NoteName[33] = "G#4";
  NoteName[34] = "A4 ";
  NoteName[35] = "A#4";
  NoteName[36] = "B4 ";
}
