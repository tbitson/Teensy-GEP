/*******************************************************************************
   Global settings variables and functions to
   save and load to non-volatile memory (EEPROM)

   version 0.81


*******************************************************************************/



// if the first byte of stored data matches this, it
// is assumed valid data for this version
#define EEPROM_VERSION 134

// save at beginning of eeprom space
const uint16_t eeAddress = 0;




//  configuration structure
struct Config
{
  byte    vers;
  
  float   bass;
  float   mid_bass;
  float   midrange;
  float   mid_treble;
  float   treble;
  
  uint8_t compressorGain;
  uint8_t compressorResponse;
  int32_t compressorThreshold;
  int32_t compressorAttack;
  int32_t compressorDecay;
  
  float   tremoloSpeed;
  float   tremoloDepth;
  
  float   flangerSpeed;
  int     flangerDepth;
  
  int     delayTime1 ;
  int     delayTime2 ;
  int     delayTime3;
  int     delayTime4 ;
  float   reverbVolume;
  
  int     inputValueAdj;
  byte    test;               // debugging - remove

  // add:
  // current screen
  // effects switches state
};

// create globalinstance
Config  config;


// global settings and initial values

#define HEADPHONE_OUTPUT_LEVEL 0.7
#define LINEOUT_AUDIO_LEVEL    8


// EQ bands
const float BASS_FREQUENCY       = 100;
const float MID_BASS_FREQUENCY   = 250;
const float MIDRANGE_FREQUENCY   = 600;
const float MID_TREBLE_FREQUENCY = 1300;
const float TREBLE_FREQUENCY     = 3000;

// wah-wah settings
const int WAH_WAH_CENTER_FREQ = 500;
const int WAH_WAH_GAIN        = 4;
const int WAH_WAH_OCTAVES     = 2;  // +/- 2 octaves




// global vars & defaults

// utility
byte vers;
byte test = 0x55;

// equalizer
float bass        = 0.0;
float mid_bass    = 0.0;
float midrange    = 0.0;
float mid_treble  = 0.0;
float treble      = 0.0;
float maxEQ       = 0.0;

// compressor
uint8_t compressorGain      = 0;
uint8_t compressorResponse  = 0;
int32_t compressorThreshold = 0;
int32_t compressorAttack    = 0;
int32_t compressorDecay     = 0;


// tremolo
float tremoloSpeed    = 3.0;
float tremoloDepth    = 0.2;

// reverb
float    reverbVolume = 0.3;
uint32_t delayTime1   = 10;
uint32_t delayTime2   = 20;
uint32_t delayTime3   = 40;
uint32_t delayTime4   = 80;


// flanger
const int FLANGE_DELAY_LENGTH = 8 * AUDIO_BLOCK_SAMPLES;
const int MAX_FLANGER_DEPTH   = FLANGE_DELAY_LENGTH / 4;
const int SIDX                = FLANGE_DELAY_LENGTH / 4;
int   flangerDepth            = FLANGE_DELAY_LENGTH / 8;
float flangerSpeed            = 0.3;   // 3.3 second sweep
short delayline[FLANGE_DELAY_LENGTH];


// input level
int inputValueAdj = 10;



// new version in work
void newSaveConfig()
{
  EEPROM.put(eeAddress, config);
  Serial.println("EEPROM Config Saved");
}


void newLoadConfig()
{
  EEPROM.get(eeAddress, config);
  Serial.println("EEPROM Config Loaded");
  Serial.print("test byte = "); Serial.println(config.test);

}


void saveConfig()
{
  config.vers = EEPROM_VERSION;
  config.bass = bass;
  config.mid_bass = mid_bass;
  config.midrange = midrange;
  config.mid_treble = mid_treble;
  config.treble = treble;
  config.compressorGain = compressorGain;
  config.compressorResponse = compressorResponse;
  config.compressorThreshold = compressorThreshold;
  config.compressorAttack = compressorAttack;
  config.compressorDecay = compressorDecay;
  config.tremoloSpeed = tremoloSpeed;
  config.tremoloDepth = tremoloDepth;
  config.flangerSpeed = flangerSpeed;
  config.flangerDepth = flangerDepth;
  config.delayTime1 = delayTime1;
  config.delayTime2 = delayTime2;
  config.delayTime3 = delayTime3;
  config.delayTime4 = delayTime4;
  config.reverbVolume = reverbVolume;
  config.inputValueAdj = inputValueAdj;
  config.test = 0x55;

  EEPROM.put(eeAddress, config);
  Serial.println("Config Saved");
}



void loadConfig()
{
  uint16_t eeAddress = 0;
  EEPROM.get(eeAddress, config);

  vers = config.vers;
  bass = config.bass;
  mid_bass = config.mid_bass;
  midrange = config.midrange;
  mid_treble = config.mid_treble;
  treble = config.treble;
  compressorGain = config.compressorGain;
  compressorResponse = config.compressorResponse;
  compressorThreshold = config.compressorThreshold;
  compressorAttack = config.compressorAttack;
  compressorDecay = config.compressorDecay;
  tremoloSpeed = config.tremoloSpeed;
  tremoloDepth = config.tremoloDepth;
  flangerSpeed = config.flangerSpeed;
  flangerDepth = config.flangerDepth;
  delayTime1 = config.delayTime1;
  delayTime2 = config.delayTime2;
  delayTime3 = config.delayTime3;
  delayTime4 = config.delayTime4;
  reverbVolume = config.reverbVolume;
  inputValueAdj = config.inputValueAdj;
  byte test = config.test;

  Serial.print("test byte (0x55) = "); Serial.println(test, HEX);
  Serial.println("Config Loaded");
}


// debugging use
void showConfig()
{
  Serial.println(F("Config = "));
  Serial.print(F("vers = ")); Serial.println(vers, HEX);
  Serial.print(F("bass = ")); Serial.println(bass);
  Serial.print(F("mid_bass = ")); Serial.println(mid_bass);
  Serial.print(F("midrange = ")); Serial.println(midrange);
  Serial.print(F("mid_treble = ")); Serial.println(mid_treble);
  Serial.print(F("treble = ")); Serial.println(treble);
  Serial.print(F("compressorGain = ")); Serial.println(compressorGain);
  Serial.print(F("compressorResponse = ")); Serial.println(compressorResponse);
  Serial.print(F("compressorThreshold = ")); Serial.println(compressorThreshold);
  Serial.print(F("compressorAttack = ")); Serial.println(compressorAttack);
  Serial.print(F("compressorDecay = ")); Serial.println(compressorDecay);
  Serial.print(F("tremoloSpeed = ")); Serial.println(tremoloSpeed);
  Serial.print(F("tremoloDepth = ")); Serial.println(tremoloDepth);
  Serial.print(F("flangerSpeed = ")); Serial.println(flangerSpeed);
  Serial.print(F("flangerDepth = ")); Serial.println(flangerDepth);
  Serial.print(F("delayTime1 = ")); Serial.println(delayTime1);
  Serial.print(F("delayTime2 = ")); Serial.println(delayTime2);
  Serial.print(F("delayTime3 = ")); Serial.println(delayTime3);
  Serial.print(F("delayTime4 = ")); Serial.println(delayTime4);
  Serial.print(F("reverbVolume = ")); Serial.println(reverbVolume);
  Serial.print(F("inputValueAdj = ")); Serial.println(inputValueAdj);
  Serial.print(F("EOF Test = 0x")); Serial.println(test, HEX);
  Serial.println();
}




// clear eeprom contents (dev use only so far)
void clearEEPROM()
{
  Serial.println("Clearing EEPROM...");

  for (int i = 0 ; i < EEPROM.length() ; i++)
    EEPROM.write(i, 0);

  Serial.println("done");
}
