




#include "ILI9341_t3.h"
#include "font_Arial.h"

extern const String VERSION;
extern ILI9341_t3 tft;
extern bool msgFlag;


void tftPrint(String msg);
void tftPrint(String msg, String val);
void tftPrint(String msg, float val);
void tftPrint(String msg, int val);
void tftPrint(String msg, uint8_t val);
void tftPrint(String msg, uint16_t val);
void tftPrint(String msg, long val);
void checkLine();


uint16_t lineCount = 0;



void tftPrint(String msg)
{
  tft.println(msg);
  Serial.println(msg);
  checkLine();
}



void tftPrint(String msg, String val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val);

}


void tftPrint(String msg, float val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val, 3);
}

void tftPrint(String msg, int val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val);
}

void tftPrint(String msg, uint8_t val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val);
}

void tftPrint(String msg, uint16_t val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val);
}



void tftPrint(String msg, long val)
{
  tft.print(msg);
  tft.print(": ");
  tft.println(val);
  checkLine();

  Serial.print(msg);
  Serial.print(": ");
  Serial.println(val);
}


void checkLine()
{
  lineCount++;

  if (lineCount > 15)
  {
      tft.fillScreen(ILI9341_BLACK);
      tft.setCursor(0, 0);
    lineCount = 0;
  }
}
