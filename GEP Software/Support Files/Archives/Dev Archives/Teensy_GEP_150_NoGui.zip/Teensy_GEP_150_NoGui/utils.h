/*******************************************************************************
     TFT LCD Functions and misc utils


*******************************************************************************/


#include "ILI9341_t3.h"
#include "font_Arial.h"

extern const String VERSION;
extern ILI9341_t3 tft;
extern bool msgFlag;





void drawBorder(uint16_t borderColor) 
{
  tft.drawRect(0, 0, 319, 239, borderColor);
}


// show message on the lcd
void tftMessage(String message)
{
  String msg = "MSG: ";
  tftPrint(msg, message);
  msgFlag = false;
}





void printAudioMemUsage()
{
  tftPrint("CPU Usage Max", AudioProcessorUsageMax());
  tftPrint("AudioProc", AudioProcessorUsage());
  tftPrint("AudioProc max", AudioProcessorUsageMax());
  tftPrint("AudioMem", AudioMemoryUsage());
  tftPrint("AudioMem max", AudioMemoryUsageMax());
  tftPrint("");
}
