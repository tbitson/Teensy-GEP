/*  audio patches from the GUI tool
 *   
 */


// GUItool: begin automatically generated code
AudioInputI2S            i2s1;           //xy=183,237
AudioSynthWaveformSine   sine1;          //xy=183,483
AudioSynthWaveformDc     dc1;            //xy=183,546
AudioSynthWaveformDc     dc2;            //xy=186,408
AudioMixer4              mixer2;         //xy=383,585
AudioAnalyzePeak         peak1;          //xy=463,76
AudioAnalyzeNoteFrequency notefreq1;      //xy=463,137
AudioEffectFlange        flange1;        //xy=558,378
AudioEffectFreeverb      freeverb1;      //xy=559,254
AudioFilterStateVariable filter1;        //xy=559,316
AudioEffectMultiply      multiply1;      //xy=560,452
AudioMixer4              mixer1;         //xy=947,334
AudioMixer4              mixer3;         //xy=1143,210
AudioOutputI2S           i2s2;           //xy=1382,317
AudioConnection          patchCord1(i2s1, 0, multiply1, 0);
AudioConnection          patchCord2(i2s1, 0, flange1, 0);
AudioConnection          patchCord3(i2s1, 0, notefreq1, 0);
AudioConnection          patchCord4(i2s1, 0, peak1, 0);
AudioConnection          patchCord5(i2s1, 0, filter1, 0);
AudioConnection          patchCord6(i2s1, 0, freeverb1, 0);
AudioConnection          patchCord7(i2s1, 0, mixer3, 0);
AudioConnection          patchCord8(sine1, 0, mixer2, 0);
AudioConnection          patchCord9(dc1, 0, mixer2, 1);
AudioConnection          patchCord10(dc2, 0, filter1, 1);
AudioConnection          patchCord11(mixer2, 0, multiply1, 1);
AudioConnection          patchCord12(flange1, 0, mixer1, 3);
AudioConnection          patchCord13(freeverb1, 0, mixer1, 0);
AudioConnection          patchCord14(filter1, 0, mixer1, 2);
AudioConnection          patchCord15(multiply1, 0, mixer1, 1);
AudioConnection          patchCord16(mixer1, 0, mixer3, 1);
AudioConnection          patchCord17(mixer3, 0, i2s2, 0);
AudioConnection          patchCord18(mixer3, 0, i2s2, 1);
AudioControlSGTL5000     audioShield;    //xy=225,722
// GUItool: end automatically generated code

// based on the above:
// mixer 1 channels
#define REVERB  0
#define TREMOLO 1
#define WAHWAH  2
#define FLANGER 3

// mixer 3 channels
#define DRY     0
#define WET     1



/*

// GUItool: begin automatically generated code
AudioInputI2S            i2s1;           //xy=55,200
AudioSynthWaveformSine   sine1;          //xy=55,446
AudioSynthWaveformDc     dc1;            //xy=55,509
AudioSynthWaveformDc     dc2;            //xy=58,371
AudioMixer4              mixer2;         //xy=305,473
AudioAnalyzePeak         peak1;          //xy=335,39
AudioAnalyzeNoteFrequency notefreq1;      //xy=335,100
AudioEffectMultiply      multiply1;      //xy=490,411
AudioFilterStateVariable filter1;        //xy=539,255
AudioEffectFlange        flange1;        //xy=561,333
AudioEffectFreeverb      freeverb1;      //xy=564,168
AudioMixer4              mixer1;         //xy=1291,315
AudioOutputI2S           i2s2;           //xy=1472,291
AudioConnection          patchCord1(i2s1, 0, multiply1, 0);
AudioConnection          patchCord2(i2s1, 0, flange1, 0);
AudioConnection          patchCord3(i2s1, 0, notefreq1, 0);
AudioConnection          patchCord4(i2s1, 0, peak1, 0);
AudioConnection          patchCord5(i2s1, 0, filter1, 0);
AudioConnection          patchCord6(i2s1, 0, freeverb1, 0);
AudioConnection          patchCord7(sine1, 0, mixer2, 0);
AudioConnection          patchCord8(dc1, 0, mixer2, 1);
AudioConnection          patchCord9(dc2, 0, filter1, 1);
AudioConnection          patchCord10(mixer2, 0, multiply1, 1);
AudioConnection          patchCord11(multiply1, 0, mixer1, 1);
AudioConnection          patchCord12(filter1, 0, mixer1, 2);
AudioConnection          patchCord13(flange1, 0, mixer1, 3);
AudioConnection          patchCord14(freeverb1, 0, mixer1, 0);
AudioConnection          patchCord15(mixer1, 0, i2s2, 0);
AudioConnection          patchCord16(mixer1, 0, i2s2, 1);
AudioControlSGTL5000     audioShield;    //xy=97,685
// GUItool: end automatically generated code


*/
