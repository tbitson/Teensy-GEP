/*
 * Hardware connections
 * 
 * 
 */
 


// Teensy Audio Lib:
// Needed defines for direct access to audio chip. These
// were copied from 'control_sgtl5000.cpp', should have been
// in a .h file we could have included. Also, the following 
// 2 functions were moved out of 'protected' in 'control_sgtl5000.h'
// so they could be accessed in our code:
// unsigned int modify(...)
// bool write(...)
#define DAP_CONTROL        0x0100
#define CHIP_SSS_CTRL      0x000A
#define DAP_AVC_CTRL       0x0124
#define DAP_AVC_THRESHOLD  0x0126
#define DAP_AVC_ATTACK     0x0128
#define DAP_AVC_DECAY      0x012A
#define DAP_MAIN_CHAN      0x0120
#define DAP_MIX_CHAN       0x0122




// TFT pins
#define TFT_DC   20
#define TFT_CS   21
#define TFT_RST  255
#define TFT_MOSI 7
#define TFT_SCLK 14
#define TFT_MISO 12

// touchscreen
#define CS_PIN  8  // touchscreen CS line

// rotary encoder pins
#define ENCODER1_PIN1   1
#define ENCODER1_PIN2   2
#define ENCODER2_PIN1   4
#define ENCODER2_PIN2   5

// define pins for the switches
#define TUNER_SWITCH_PIN      0   // D0
#define SAVE_SWITCH_PIN       17  // A3
#define COMPRESSOR_SWITCH_PIN 10  // D10


// Switch Debounce Time = 15ms
#define DEBOUNCE_MS    15

// PCF8574 is the interface to the buttons & leds
// I2C address
#define PCF8574_ADDRESS  0x20

// PCF8574 LEDs
#define LED_ON      0
#define LED_OFF     1

#define REVERB_LED   7
#define FLANGER_LED  6
#define TREMOLO_LED  5
#define WAH_WAH_LED  4

// PCF8574 Switches
#define SWITCH_ON       0
#define SWITCH_OFF      1

#define REVERB_SWITCH   0
#define FLANGER_SWITCH  1
#define TREMOLO_SWITCH  2
#define WAH_WAH_SWITCH  3

// on-board potentiometers - could be pedal inputs
#define WAH_WAH_POT   A1
#define BALANCE_POT   A2
#define POT_DELTA_VALUE 20   // was 12
