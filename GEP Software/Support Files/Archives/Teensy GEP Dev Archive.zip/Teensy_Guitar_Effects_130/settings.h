/************************************** 
 *  initial settings and constants
 *  
 **************************************/





#define HEADPHONE_OUTPUT_LEVEL 0.5
#define LINEOUT_AUDIO_LEVEL    13


// EQ bands
const float BASS_FREQUENCY = 100;
const float MID_BASS_FREQUENCY = 250;
const float MIDRANGE_FREQUENCY = 600;
const float MID_TREBLE_FREQUENCY = 1300;
const float TREBLE_FREQUENCY = 3000;

// wah-wah settings
const int WAH_WAH_CENTER_FREQ = 500;
const int WAH_WAH_GAIN = 4;
const int WAH_WAH_OCTAVES = 2;  // +/- 2 octaves


// global vars & defaults
float tremoloSpeed = 3.0;
float tremoloDepth = 0.2;

float    reverbVolume = 0.3;

uint32_t delayTime1 = 100;
uint32_t delayTime2 = 200;
uint32_t delayTime3 = 300;
uint32_t delayTime4 = 400;

const int FLANGE_DELAY_LENGTH = 8 * AUDIO_BLOCK_SAMPLES;
const int MAX_FLANGER_DEPTH = FLANGE_DELAY_LENGTH / 4;  // beyond this you get artifacts/distortion
const int SIDX = FLANGE_DELAY_LENGTH / 4;
short delayline[FLANGE_DELAY_LENGTH];
int flangerDepth = FLANGE_DELAY_LENGTH / 4;
float flangerSpeed = 0.3;   // 3.3 second sweep

// 0.56V p-p input sensitivity
int inputValueAdj = 10;


// GUI Constants
const uint16_t GUI_ELEMENT_COLOR = ILI9341_YELLOW;
const uint16_t GUI_FOCUS_ELEMENT_COLOR = ILI9341_RED;
