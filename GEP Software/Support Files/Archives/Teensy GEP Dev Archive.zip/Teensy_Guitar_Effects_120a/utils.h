



#include "ILI9341_t3.h"
#include "font_Arial.h"
#include "logo.c"


extern ILI9341_t3 tft;
extern bool msgFlag;


// display splash Screen
void splashScreen()
{
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.writeRect(80, 20, logo.width, logo.height, (uint16_t*)(logo.pixel_data));
  
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(100, 100);
  tft.setFont(Arial_20);
  tft.print("Teensy");
  
  tft.setCursor(10, 140);
  tft.setFont(Arial_20);
  tft.print("Guitar Effects Processor");
  
  tft.setCursor(85, 180);
  tft.setFont(Arial_14);
  tft.print(VERSION);
  
  delay(6000);
}





// show message on the lcd
void tftMessage(String message)
{
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(80, 60);
  tft.setFont(Arial_16);
  tft.print(message);
  delay(2000);
  tft.fillScreen(ILI9341_BLACK);
  msgFlag = false;

}
