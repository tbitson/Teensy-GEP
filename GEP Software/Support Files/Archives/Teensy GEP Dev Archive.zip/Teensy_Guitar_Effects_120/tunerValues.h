// guitar tuner frequency and name arrays


extern float Guitar_Note[];
extern String NoteName[];


void Assign_Guitar_Note_Array()
{
  Guitar_Note[1] = 61.714;
  Guitar_Note[2] = 65.385;
  Guitar_Note[3] = 69.268;
  Guitar_Note[4] = 73.425;
  Guitar_Note[5] = 82.410;
  Guitar_Note[6] = 87.273;
  Guitar_Note[7] = 92.500;
  Guitar_Note[8] = 98.000;
  Guitar_Note[9] = 103.784;
  Guitar_Note[10] = 110.000;
  Guitar_Note[11] = 116.522;
  Guitar_Note[12] = 123.249;
  Guitar_Note[13] = 130.769;
  Guitar_Note[14] = 138.537;
  Guitar_Note[15] = 146.830;
  Guitar_Note[16] = 155.556;
  Guitar_Note[17] = 164.800;
  Guitar_Note[18] = 174.545;
  Guitar_Note[19] = 185.000;
  Guitar_Note[20] = 196.000;
  Guitar_Note[21] = 207.568;
  Guitar_Note[22] = 220.000;
  Guitar_Note[23] = 233.043;
  Guitar_Note[24] = 246.940;
  Guitar_Note[25] = 261.538;
  Guitar_Note[26] = 277.073;
  Guitar_Note[27] = 293.699;
  Guitar_Note[28] = 311.111;
  Guitar_Note[29] = 329.630;
  Guitar_Note[30] = 349.091;
  Guitar_Note[31] = 370.000;
  Guitar_Note[32] = 392.000;
  Guitar_Note[33] = 415.135;
  Guitar_Note[34] = 440.000;
  Guitar_Note[35] = 466.087;


  NoteName[1] = "C2 ";
  NoteName[2] = "C#2";
  NoteName[3] = "D2 ";
  NoteName[4] = "D#2";
  NoteName[5] = "E2 ";
  NoteName[6] = "F2 ";
  NoteName[7] = "F#2";
  NoteName[8] = "G2 ";
  NoteName[9] = "G#2";
  NoteName[10] = "A2 ";
  NoteName[11] = "A#2";
  NoteName[12] = "B2 ";
  NoteName[13] = "C3 ";
  NoteName[14] = "C#3";
  NoteName[15] = "D3 ";
  NoteName[16] = "D#3";
  NoteName[17] = "E3 ";
  NoteName[18] = "F3 ";
  NoteName[19] = "F#3";
  NoteName[20] = "G3 ";
  NoteName[21] = "G#3";
  NoteName[22] = "A3 ";
  NoteName[23] = "A#3";
  NoteName[24] = "B3 ";
  NoteName[25] = "C4 ";
  NoteName[26] = "C#4";
  NoteName[27] = "D4 ";
  NoteName[28] = "D#4";
  NoteName[29] = "E4 ";
  NoteName[30] = "F4 ";
  NoteName[31] = "F#4";
  NoteName[32] = "G4 ";
  NoteName[33] = "G#4";
  NoteName[34] = "A4 ";
  NoteName[35] = "A#4";
  NoteName[36] = "B4 ";
}
