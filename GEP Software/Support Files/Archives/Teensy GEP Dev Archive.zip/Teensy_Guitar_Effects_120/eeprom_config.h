




// if first byte of stored data matches this, it
// is assumed valid data
#define EEPROM_VALID 0xAA



//  EEPROM data structure to save/load ALL config parameters at power-up
struct Config
{
  // ID is used to check validity of eeprom contents, should match the #def above
  byte ID = EEPROM_VALID;
  
  // eq settings
  float bass;
  float mid_bass;
  float midrange;
  float mid_treble;
  float treble;
  // float maxEQ;

  // compressor settings
  uint8_t compressorGain;
  uint8_t compressorResponse;
  int32_t compressorThreshold;
  int32_t compressorAttack;
  int32_t compressorDecay;
  // boolean compressor active

  // tremolo settings
  float tremoloSpeed;
  float tremoloDepth;

  // flanger settings
  float flangerSpeed;
  int flangerDepth;

  // reverb settings
  int delayTime1 ;
  int delayTime2 ;
  int delayTime3;
  int delayTime4 ;
  float reverbVolume;

  // input level
  int inputValueAdj;
};
