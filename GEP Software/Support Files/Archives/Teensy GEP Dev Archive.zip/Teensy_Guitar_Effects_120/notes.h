/*
 * 
 * 

Font sizes:
  Arial_8,
  Arial_9,
  Arial_10,
  Arial_11,
  Arial_12,
  Arial_13,
  Arial_14,
  Arial_16,
  Arial_18,
  Arial_20,
  Arial_24,
  Arial_28,
  Arial_32,
  Arial_40,
  Arial_48,
  Arial_60,
  Arial_72,
  Arial_96


// my settings
EEPROM_VALID = AA
bass = 2.74
mid_bass = 0.00
midrange = 0.00
mid_treble = 0.00
treble = 0.00
compressorGain = 1
compressorResponse = 2
compressorThreshold = 16000
compressorAttack = 384
compressorDecay = 544
tremoloSpeed = 3.80
tremoloDepth = 0.38
flangerSpeed = 0.69
flangerDepth = 216
delayTime1 = 285
delayTime2 = 514
delayTime3 = 700
delayTime4 = 828
reverbVolume = 0.80
inputValueAdj = 5


// DEFAULTS VALUES (vars not valid anymore)
EEPROM_VALID = 0xAA
bass = -1.08
mid_bass = 0.00
midrange = 0.00
mid_treble = 0.00
treble = 0.00
Compressor_Gain = 0
Compressor_Response = 0
Compressor_Threshold = 0
Compressor_Attack = 0
Compressor_Decay = 0
tremolo_Speed = 3.00
tremolo_Depth = 0.20
Flanger_Speed = 0.30
Flanger_Depth = 256
Delay_Time1 = 100
Delay_Time2 = 200
Delay_Time3 = 300
Delay_Time4 = 400
Reverb_Volume = 0.30
Input_Trim_Value = 10
EEPROM Config Saved

/*
