/*******************************************************************************
   Save and read configuration from eeprom
   non-volatile storage


*******************************************************************************/

// global vars we'll save and load
extern float bass;
extern float mid_bass;
extern float midrange;
extern float mid_treble;
extern float treble;
extern float maxEQ;
extern uint8_t compressorGain;
extern uint8_t compressorResponse;
extern int32_t compressorThreshold;
extern int32_t compressorAttack;
extern int32_t compressorDecay;
extern float tremoloSpeed;
extern float tremoloDepth;
extern float    reverbVolume;
extern uint32_t delayTime1;
extern uint32_t delayTime2;
extern uint32_t delayTime3;
extern uint32_t delayTime4;
extern int flangerDepth;
extern float flangerSpeed;
extern int inputValueAdj;



// if the first byte of stored data matches this, it
// is assumed valid data for this version
#define EEPROM_VERSION 130



// save at beginning of eeprom space
uint16_t eeAddress = 0;
byte vers;




//  EEPROM data structure
struct Config
{
  byte    vers;
  float   bass;
  float   mid_bass;
  float   midrange;
  float   mid_treble;
  float   treble;
  uint8_t compressorGain;
  uint8_t compressorResponse;
  int32_t compressorThreshold;
  int32_t compressorAttack;
  int32_t compressorDecay;
  float   tremoloSpeed;
  float   tremoloDepth;
  float   flangerSpeed;
  int     flangerDepth;
  int     delayTime1 ;
  int     delayTime2 ;
  int     delayTime3;
  int     delayTime4 ;
  float   reverbVolume;
  int     inputValueAdj;
  byte    test;               // debugging - remove

  // add:
  // current screen
  // effects switches state
};



// create an instance of eeprom config struct
Config  config;


// new version in work
void newSaveConfig()
{
  EEPROM.put(eeAddress, config);
  Serial.println("EEPROM Config Saved");
}


void newLoadConfig()
{
  EEPROM.get(eeAddress, config);
  Serial.println("EEPROM Config Loaded");
  Serial.print("test byte = "); Serial.println(config.test);

}


void saveConfig()
{
  config.vers = EEPROM_VERSION;
  config.bass = bass;
  config.mid_bass = mid_bass;
  config.midrange = midrange;
  config.mid_treble = mid_treble;
  config.treble = treble;
  config.compressorGain = compressorGain;
  config.compressorResponse = compressorResponse;
  config.compressorThreshold = compressorThreshold;
  config.compressorAttack = compressorAttack;
  config.compressorDecay = compressorDecay;
  config.tremoloSpeed = tremoloSpeed;
  config.tremoloDepth = tremoloDepth;
  config.flangerSpeed = flangerSpeed;
  config.flangerDepth = flangerDepth;
  config.delayTime1 = delayTime1;
  config.delayTime2 = delayTime2;
  config.delayTime3 = delayTime3;
  config.delayTime4 = delayTime4;
  config.reverbVolume = reverbVolume;
  config.inputValueAdj = inputValueAdj;
  config.test = 0x55;

  EEPROM.put(eeAddress, config);
  Serial.println("Config Saved");
}



void loadConfig()
{
  uint16_t eeAddress = 0;
  EEPROM.get(eeAddress, config);

  vers = config.vers;
  bass = config.bass;
  mid_bass = config.mid_bass;
  midrange = config.midrange;
  mid_treble = config.mid_treble;
  treble = config.treble;
  compressorGain = config.compressorGain;
  compressorResponse = config.compressorResponse;
  compressorThreshold = config.compressorThreshold;
  compressorAttack = config.compressorAttack;
  compressorDecay = config.compressorDecay;
  tremoloSpeed = config.tremoloSpeed;
  tremoloDepth = config.tremoloDepth;
  flangerSpeed = config.flangerSpeed;
  flangerDepth = config.flangerDepth;
  delayTime1 = config.delayTime1;
  delayTime2 = config.delayTime2;
  delayTime3 = config.delayTime3;
  delayTime4 = config.delayTime4;
  reverbVolume = config.reverbVolume;
  inputValueAdj = config.inputValueAdj;
  byte test = config.test;

  Serial.print("test byte = "); Serial.println(test);

  Serial.println("Config Loaded");
}


// debugging use
void showConfig()
{
  Serial.print(F("vers = ")); Serial.println(vers, HEX);
  Serial.print(F("bass = ")); Serial.println(bass);
  Serial.print(F("mid_bass = ")); Serial.println(mid_bass);
  Serial.print(F("midrange = ")); Serial.println(midrange);
  Serial.print(F("mid_treble = ")); Serial.println(mid_treble);
  Serial.print(F("treble = ")); Serial.println(treble);
  Serial.print(F("compressorGain = ")); Serial.println(compressorGain);
  Serial.print(F("compressorResponse = ")); Serial.println(compressorResponse);
  Serial.print(F("compressorThreshold = ")); Serial.println(compressorThreshold);
  Serial.print(F("compressorAttack = ")); Serial.println(compressorAttack);
  Serial.print(F("compressorDecay = ")); Serial.println(compressorDecay);
  Serial.print(F("tremoloSpeed = ")); Serial.println(tremoloSpeed);
  Serial.print(F("tremoloDepth = ")); Serial.println(tremoloDepth);
  Serial.print(F("flangerSpeed = ")); Serial.println(flangerSpeed);
  Serial.print(F("flangerDepth = ")); Serial.println(flangerDepth);
  Serial.print(F("delayTime1 = ")); Serial.println(delayTime1);
  Serial.print(F("delayTime2 = ")); Serial.println(delayTime2);
  Serial.print(F("delayTime3 = ")); Serial.println(delayTime3);
  Serial.print(F("delayTime4 = ")); Serial.println(delayTime4);
  Serial.print(F("reverbVolume = ")); Serial.println(reverbVolume);
  Serial.print(F("inputValueAdj = ")); Serial.println(inputValueAdj);
}




// clear eeprom contents (dev use only so far)
void clearEEPROM()
{
  Serial.println("Clearing EEPROM...");

  for (int i = 0 ; i < EEPROM.length() ; i++)
    EEPROM.write(i, 0);

  Serial.println("done");
}
