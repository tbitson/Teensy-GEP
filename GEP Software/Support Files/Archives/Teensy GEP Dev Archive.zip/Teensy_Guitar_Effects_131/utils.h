/*******************************************************************************
     TFT LCD Functions and misc utils


*******************************************************************************/



#include "ILI9341_t3.h"
#include "font_Arial.h"
#include "logo.c"


extern ILI9341_t3 tft;
extern bool msgFlag;


// display splash Screen
void splashScreen()
{
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.writeRect(80, 20, logo.width, logo.height, (uint16_t*)(logo.pixel_data));

  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(100, 100);
  tft.setFont(Arial_20);
  tft.print("Teensy");

  tft.setCursor(10, 140);
  tft.setFont(Arial_20);
  tft.print("Guitar Effects Processor");

  tft.setCursor(85, 180);
  tft.setFont(Arial_14);
  tft.print(VERSION);

  delay(5000);
}



// show message on the lcd
void tftMessage(String message)
{
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRect(0, 0, 319, 239, ILI9341_RED);
  tft.setTextColor(ILI9341_YELLOW);
  tft.setCursor(80, 60);
  tft.setFont(Arial_16);
  tft.print(message);
  delay(1500);
  tft.fillScreen(ILI9341_BLACK);
  msgFlag = false;
}


// in work
void drawSlider(uint16_t x, uint16_t y, uint8_t level, bool focus)
{
  // tbd
  // x, y - starting pos
  // level - % full scale 0 -100
  uint16_t width = 29;
  uint16_t height = 192;
  uint16_t radious = 8;
  level = level * (height - 3) / 100;


  // body
  tft.fillRoundRect( x, y, width, height, radious, ILI9341_BLUE);

  // handle
  tft.fillRoundRect(x, level, width, 10, radious, ILI9341_YELLOW);
  tft.fillRect(x + width, level + 3, width, radious / 2, ILI9341_BLACK);

}



void displayMemUsage()
{
  Serial.print("Memory Usage: ");
  Serial.print("AudioProcessor: "); Serial.print(AudioProcessorUsage());
  Serial.print("  max: "); Serial.print(AudioProcessorUsageMax());
  Serial.print(",   AudioMem: = "); Serial.print(AudioMemoryUsage());
  Serial.print("  max: "); Serial.print(AudioMemoryUsageMax());
  Serial.println();
  
  AudioProcessorUsageMaxReset();
  AudioMemoryUsageMaxReset();
}
