/**************************************   
 * utils. h - various support functions
 * 
 * version 1.1.0   Dec 2019
 * 
 * Various utility and helper functions
 * 
 * 
 ***************************************/



// prototypes
void printValue(const char* msg);
void printValue(String, int);
void printValue(String, long);
void printValue(String, float);
void printValue(const char*, int, float);
void printArryValue(const char* , uint8_t, float);
void printAudioMemUsage();





// simple helper functions that print data to the serial port
// undefining DEBUG_PRINT disables all output
void printValue(const char* msg)
{
#ifdef DEBUG_PRINT
  Serial.print("msg = ");
  Serial.println(msg);
#endif
}


void printValue(const char* msg, int val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val);
#endif
}


void printValue(const char* msg, long val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val);
#endif
}


void printValue(const char* msg, float val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" = ");
  Serial.println(val, 1);
#endif
}


void printValue(const char* msg, int val1, float val2)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print(" ");
  Serial.print(val1);
  Serial.print(" = ");
  Serial.println(val2);
#endif
}


void printArryValue(const char* msg, uint8_t index, float val)
{
#ifdef DEBUG_PRINT
  Serial.print(msg);
  Serial.print("[");
  Serial.print(index);
  Serial.print("] = ");
  Serial.println(val);
#endif
}



uint32_t teensyFreeMem()
{
    uint32_t stackTop;
    uint32_t heapTop;

    // current position of the stack.
    stackTop = (uint32_t) &stackTop;

    // current position of heap.
    void* hTop = malloc(1);
    heapTop = (uint32_t) hTop;
    free(hTop);
    return stackTop - heapTop;
}


void printAudioMemUsage()
{
  Serial.println(F("CPU Usage"));
  Serial.print(F("Freeverb Usage : ")); Serial.println(freeverb1.processorUsage());
  Serial.print(F("Delayer Usage  : ")); Serial.println(delayExt1.processorUsage());

  Serial.print(F("AudioProcessor : ")); Serial.print(AudioProcessorUsage());
  Serial.print(F("   max: "));          Serial.println(AudioProcessorUsageMax());

  Serial.print(F("Audio Mem      : ")); Serial.print(AudioMemoryUsage());
  Serial.print(F("   max: "));      Serial.println(AudioMemoryUsageMax());
  
  Serial.print(F("Free RAM       : ")); Serial.println(teensyFreeMem());  
  Serial.println();
}
